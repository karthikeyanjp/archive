import { Card, CardContent, CardHeader, Box, Typography } from '@mui/material';
import { LineChart } from '@mui/x-charts/LineChart';
import { mockMetrics } from "@/lib/mock-data";

export default function UsageChart() {
  const chartData = mockMetrics
    .filter(metric => metric.month)
    .reduce((acc, metric) => {
      const existingMonth = acc.find(item => item.month === metric.month);
      if (existingMonth) {
        if (metric.libraryId === 1) {
          existingMonth.nodejs = metric.projects;
        } else {
          existingMonth.golang = metric.projects;
        }
      } else {
        acc.push({
          month: metric.month,
          nodejs: metric.libraryId === 1 ? metric.projects : 0,
          golang: metric.libraryId === 2 ? metric.projects : 0,
        });
      }
      return acc;
    }, [] as Array<{ month: string; nodejs: number; golang: number }>)
    .sort((a, b) => {
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      return months.indexOf(a.month) - months.indexOf(b.month);
    });

  const xAxisData = chartData.map(item => item.month);
  const nodejsData = chartData.map(item => item.nodejs);
  const golangData = chartData.map(item => item.golang);

  return (
    <Card sx={{ height: '100%' }}>
      <CardHeader sx={{ pb: 2 }}>
        <Typography variant="h6" component="h3" sx={{ fontWeight: 'medium' }}>
          Usage Growth Over Time
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Monthly project adoption for both libraries
        </Typography>
      </CardHeader>
      <CardContent sx={{ pt: 1 }}>
        <Box sx={{ height: 300 }}>
          <LineChart
            xAxis={[{ 
              scaleType: 'point', 
              data: xAxisData,
              tickLabelStyle: { fontSize: 12 }
            }]}
            series={[
              {
                data: nodejsData,
                label: 'Node.js Library',
                color: '#10b981'
              },
              {
                data: golangData,
                label: 'Golang Library', 
                color: '#2563eb'
              }
            ]}
            width={undefined}
            height={300}
          />
        </Box>
      </CardContent>
    </Card>
  );
}
