import { Card, CardContent, CardHeader, Box, Typography, Button, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Avatar, Paper } from '@mui/material';
import { CloudDownload } from '@mui/icons-material';
import { mockLibraries, formatLargeNumber } from "@/lib/mock-data";

export default function MetricsTable() {
  const handleExport = () => {
    console.log("Exporting data...");
  };

  return (
    <Card>
      <CardHeader sx={{ pb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography variant="h6" component="h3" sx={{ fontWeight: 'medium' }}>
              Detailed Performance Metrics
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Comprehensive statistics across all tracked parameters
            </Typography>
          </Box>
          <Button
            variant="outlined"
            size="small"
            onClick={handleExport}
            startIcon={<CloudDownload />}
          >
            Export Data
          </Button>
        </Box>
      </CardHeader>
      <CardContent sx={{ p: 0 }}>
        <TableContainer component={Paper} elevation={0}>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: 'grey.50' }}>
                <TableCell sx={{ fontWeight: 'medium' }}>Library</TableCell>
                <TableCell sx={{ fontWeight: 'medium' }}>Language</TableCell>
                <TableCell sx={{ fontWeight: 'medium' }}>Projects</TableCell>
                <TableCell sx={{ fontWeight: 'medium' }}>Downloads</TableCell>
                <TableCell sx={{ fontWeight: 'medium' }}>Hours Saved</TableCell>
                <TableCell sx={{ fontWeight: 'medium' }}>Growth Rate</TableCell>
                <TableCell sx={{ fontWeight: 'medium' }}>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {mockLibraries.map((library) => {
                const isNodeJs = library.language.toLowerCase().includes("node");
                const avatarColor = isNodeJs ? 'success' : 'primary';
                const chipColor = isNodeJs ? 'success' : 'primary';
                
                return (
                  <TableRow 
                    key={library.id} 
                    sx={{ '&:hover': { bgcolor: 'action.hover' } }}
                  >
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Avatar sx={{ 
                          bgcolor: `${avatarColor}.main`, 
                          mr: 2,
                          width: 32,
                          height: 32
                        }}>
                          <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                            {isNodeJs ? "N" : "G"}
                          </Typography>
                        </Avatar>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                            {library.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {library.version}
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{library.language}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">
                        {formatLargeNumber(library.projectsUsing)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">
                        {formatLargeNumber(library.monthlyDownloads)}/month
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">
                        {formatLargeNumber(library.hoursSaved)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ color: 'success.main', fontWeight: 'medium' }}>
                        +{library.growthRate}%
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip 
                        label={library.status} 
                        color={chipColor}
                        variant="outlined"
                        size="small"
                      />
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </CardContent>
    </Card>
  );
}
