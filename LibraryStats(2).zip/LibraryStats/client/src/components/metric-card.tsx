import { Card, CardContent, Box, Typography, Avatar } from '@mui/material';
import { SvgIconComponent } from '@mui/icons-material';
import { TrendingUp, TrendingDown } from '@mui/icons-material';

interface MetricCardProps {
  title: string;
  value: string;
  trend?: string;
  trendDirection?: "up" | "down";
  icon: SvgIconComponent;
  color: 'primary' | 'secondary' | 'success' | 'warning' | 'error';
  description?: string;
}

export default function MetricCard({
  title,
  value,
  trend,
  trendDirection = "up",
  icon: Icon,
  color,
  description,
}: MetricCardProps) {
  return (
    <Card sx={{ 
      height: '100%',
      transition: 'box-shadow 0.2s',
      '&:hover': {
        boxShadow: 4
      }
    }}>
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Avatar sx={{ 
            bgcolor: `${color}.main`, 
            mr: 2,
            width: 48,
            height: 48
          }}>
            <Icon />
          </Avatar>
          <Box sx={{ flex: 1 }}>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              {title}
            </Typography>
            <Typography variant="h4" component="div" sx={{ fontWeight: 'bold', mb: 0.5 }}>
              {value}
            </Typography>
            {trend && (
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                {trendDirection === "up" ? (
                  <TrendingUp sx={{ fontSize: 16, color: 'success.main', mr: 0.5 }} />
                ) : (
                  <TrendingDown sx={{ fontSize: 16, color: 'error.main', mr: 0.5 }} />
                )}
                <Typography 
                  variant="body2" 
                  sx={{ 
                    color: trendDirection === "up" ? 'success.main' : 'error.main',
                    fontWeight: 'medium'
                  }}
                >
                  {trend}
                </Typography>
              </Box>
            )}
            {description && (
              <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                {description}
              </Typography>
            )}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
}
