import { Card, CardContent, CardHeader, Box, Typography } from '@mui/material';
import { PieChart } from '@mui/x-charts/PieChart';
import { mockLibraries, formatLargeNumber } from "@/lib/mock-data";

export default function EfficiencyChart() {
  const chartData = mockLibraries.map((library, index) => ({
    id: index,
    label: library.language === "Node.js" ? "Node.js Library" : "Golang Library",
    value: library.hoursSaved,
    color: index === 0 ? '#10b981' : '#2563eb',
  }));

  return (
    <Card sx={{ height: '100%' }}>
      <CardHeader sx={{ pb: 2 }}>
        <Typography variant="h6" component="h3" sx={{ fontWeight: 'medium' }}>
          Developer Hours Saved
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Cumulative time savings by library
        </Typography>
      </CardHeader>
      <CardContent sx={{ pt: 1 }}>
        <Box sx={{ height: 300 }}>
          <PieChart
            series={[
              {
                data: chartData,
                highlightScope: { faded: 'global', highlighted: 'item' },
                faded: { innerRadius: 30, additionalRadius: -30, color: 'gray' },
              },
            ]}
            width={undefined}
            height={300}
          />
        </Box>
      </CardContent>
    </Card>
  );
}
