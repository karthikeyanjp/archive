import { pgTable, serial, text, integer, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const libraries = pgTable("libraries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  language: text("language").notNull(),
  version: text("version").notNull(),
  projectsUsing: integer("projects_using").notNull().default(0),
  monthlyDownloads: integer("monthly_downloads").notNull().default(0),
  hoursSaved: integer("hours_saved").notNull().default(0),
  githubStars: integer("github_stars").notNull().default(0),
  growthRate: real("growth_rate").notNull().default(0),
  status: text("status", { enum: ["active", "inactive", "deprecated"] }).notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  libraryId: integer("library_id").references(() => libraries.id).notNull(),
  month: text("month").notNull(),
  projects: integer("projects").notNull().default(0),
  downloads: integer("downloads").notNull().default(0),
  hoursSaved: integer("hours_saved").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertLibrarySchema = createInsertSchema(libraries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMetricSchema = createInsertSchema(metrics).omit({
  id: true,
  createdAt: true,
});

// Types
export type Library = typeof libraries.$inferSelect;
export type InsertLibrary = z.infer<typeof insertLibrarySchema>;
export type Metric = typeof metrics.$inferSelect;
export type InsertMetric = z.infer<typeof insertMetricSchema>;