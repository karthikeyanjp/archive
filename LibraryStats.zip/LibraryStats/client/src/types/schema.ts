export interface Library {
  id: number;
  name: string;
  language: string;
  version: string;
  projectsUsing: number;
  monthlyDownloads: number;
  hoursSaved: number;
  githubStars: number;
  growthRate: number;
  status: "active" | "inactive" | "deprecated";
  createdAt: Date;
  updatedAt: Date;
}

export interface Metric {
  id: number;
  libraryId: number;
  month: string;
  projects: number;
  downloads: number;
  hoursSaved: number;
  createdAt: Date;
}