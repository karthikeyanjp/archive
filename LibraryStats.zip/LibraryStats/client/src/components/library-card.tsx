import { Card, CardContent, CardHeader, Box, Typography, Avatar, Chip, LinearProgress } from '@mui/material';
import { Library } from "@/types/schema";
import { formatLargeNumber } from "@/lib/static-data";

interface LibraryCardProps {
  library: Library;
}

export default function LibraryCard({ library }: LibraryCardProps) {
  const isNodeJs = library.language.toLowerCase().includes("node");
  const avatarColor = isNodeJs ? 'success' : 'primary';
  const chipColor = isNodeJs ? 'success' : 'primary';

  return (
    <Card sx={{ height: '100%' }}>
      <CardHeader sx={{ pb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Avatar sx={{ 
              bgcolor: `${avatarColor}.main`, 
              mr: 2,
              width: 40,
              height: 40
            }}>
              <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                {isNodeJs ? "N" : "G"}
              </Typography>
            </Avatar>
            <Box>
              <Typography variant="h6" component="h3" sx={{ fontWeight: 'medium' }}>
                {library.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {library.language} Package
              </Typography>
            </Box>
          </Box>
          <Chip 
            label={library.status} 
            color={chipColor}
            variant="outlined"
            size="small"
          />
        </Box>
      </CardHeader>
      <CardContent sx={{ pt: 1 }}>
        <Box sx={{ 
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 2,
          mb: 3
        }}>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h5" component="div" sx={{ fontWeight: 'bold' }}>
              {formatLargeNumber(library.projectsUsing)}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Projects Using
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h5" component="div" sx={{ fontWeight: 'bold' }}>
              {formatLargeNumber(library.hoursSaved)}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Hours Saved
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h5" component="div" sx={{ fontWeight: 'bold' }}>
              {formatLargeNumber(library.monthlyDownloads)}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Monthly Downloads
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h5" component="div" sx={{ fontWeight: 'bold' }}>
              {formatLargeNumber(library.githubStars)}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              GitHub Stars
            </Typography>
          </Box>
        </Box>
        
        <Box sx={{ pt: 2, borderTop: 1, borderColor: 'divider' }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Usage Trend
            </Typography>
            <Typography variant="body2" sx={{ color: 'success.main', fontWeight: 'medium' }}>
              +{library.growthRate}% this month
            </Typography>
          </Box>
          <LinearProgress 
            variant="determinate" 
            value={Math.min(library.growthRate * 4, 100)}
            sx={{ 
              height: 8, 
              borderRadius: 1,
              backgroundColor: 'grey.200',
              '& .MuiLinearProgress-bar': {
                backgroundColor: isNodeJs ? 'success.main' : 'primary.main'
              }
            }}
          />
        </Box>
      </CardContent>
    </Card>
  );
}
