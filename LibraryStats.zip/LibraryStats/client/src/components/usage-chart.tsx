import { Card, CardContent, CardHeader, Box, Typography, CircularProgress } from '@mui/material';
import { LineChart } from '@mui/x-charts/LineChart';
import { useQuery } from '@tanstack/react-query';

interface UsageData {
  month: string;
  React: number;
  Vue: number;
  Angular: number;
  Express: number;
}

export default function UsageChart() {
  const { data: usageData, isLoading } = useQuery<UsageData[]>({
    queryKey: ['usage-chart'],
    queryFn: () => fetch('/data/usage-chart.json').then(res => res.json()),
  });

  if (isLoading || !usageData) {
    return (
      <Card sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Card>
    );
  }

  const xAxisData = usageData.map(item => item.month);
  const reactData = usageData.map(item => item.React);
  const vueData = usageData.map(item => item.Vue);
  const angularData = usageData.map(item => item.Angular);
  const expressData = usageData.map(item => item.Express);

  return (
    <Card sx={{ height: '100%' }}>
      <CardHeader sx={{ pb: 2 }}>
        <Typography variant="h6" component="h3" sx={{ fontWeight: 'medium' }}>
          Usage Growth Over Time
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Monthly downloads for popular libraries
        </Typography>
      </CardHeader>
      <CardContent sx={{ pt: 1 }}>
        <Box sx={{ height: 300 }}>
          <LineChart
            xAxis={[{ 
              scaleType: 'point', 
              data: xAxisData,
              tickLabelStyle: { fontSize: 12 }
            }]}
            series={[
              {
                data: reactData,
                label: 'React',
                color: '#61dafb'
              },
              {
                data: expressData,
                label: 'Express',
                color: '#10b981'
              },
              {
                data: vueData,
                label: 'Vue',
                color: '#4fc08d'
              },
              {
                data: angularData,
                label: 'Angular',
                color: '#dd1b16'
              }
            ]}
            width={undefined}
            height={300}
          />
        </Box>
      </CardContent>
    </Card>
  );
}
