import { Box, Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Typography, Avatar } from '@mui/material';
import { Dashboard, LibraryBooks, Analytics, TrendingUp, Settings, Code } from '@mui/icons-material';
import { Link, useLocation } from "wouter";

const navigation = [
  { name: "Dashboard", href: "/", icon: Dashboard },
  { name: "Libraries", href: "/libraries", icon: LibraryBooks },
  { name: "Usage Analytics", href: "/analytics", icon: Analytics },
  { name: "Growth Metrics", href: "/growth", icon: TrendingUp },
  { name: "Settings", href: "/settings", icon: Settings },
];

interface SidebarProps {
  mobileOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ mobileOpen, onClose }: SidebarProps) {
  const [location] = useLocation();

  const SidebarContent = () => (
    <Box sx={{ width: 240, height: '100%', bgcolor: 'background.paper' }}>
      <Box sx={{ p: 3, borderBottom: 1, borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Avatar sx={{ bgcolor: 'primary.main', mr: 2 }}>
            <Code />
          </Avatar>
          <Typography variant="h6" component="h1" sx={{ fontWeight: 'bold' }}>
            LibraryStats
          </Typography>
        </Box>
      </Box>
      <List sx={{ px: 2, py: 1 }}>
        {navigation.map((item) => {
          const isActive = location === item.href;
          const IconComponent = item.icon;
          return (
            <ListItem key={item.name} disablePadding>
              <Link href={item.href} style={{ textDecoration: 'none', width: '100%' }}>
                <ListItemButton
                  selected={isActive}
                  onClick={onClose}
                  sx={{
                    borderRadius: 1,
                    my: 0.5,
                    '&.Mui-selected': {
                      bgcolor: 'primary.main',
                      color: 'primary.contrastText',
                      '&:hover': {
                        bgcolor: 'primary.dark',
                      },
                    },
                    '&:hover': {
                      bgcolor: 'action.hover',
                    },
                  }}
                >
                  <ListItemIcon sx={{ 
                    color: isActive ? 'primary.contrastText' : 'text.secondary',
                    minWidth: 40 
                  }}>
                    <IconComponent />
                  </ListItemIcon>
                  <ListItemText 
                    primary={item.name} 
                    sx={{ 
                      color: isActive ? 'primary.contrastText' : 'text.primary',
                    }}
                  />
                </ListItemButton>
              </Link>
            </ListItem>
          );
        })}
      </List>
    </Box>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <Drawer
        variant="permanent"
        sx={{
          display: { xs: 'none', md: 'block' },
          '& .MuiDrawer-paper': {
            boxSizing: 'border-box',
            width: 240,
            border: 'none',
            boxShadow: 1,
          },
        }}
        open
      >
        <SidebarContent />
      </Drawer>

      {/* Mobile Sidebar */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={onClose}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': {
            boxSizing: 'border-box',
            width: 240,
          },
        }}
      >
        <SidebarContent />
      </Drawer>
    </>
  );
}
