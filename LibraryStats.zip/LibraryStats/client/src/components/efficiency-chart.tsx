import { Card, CardContent, CardHeader, Box, Typography, CircularProgress } from '@mui/material';
import { PieChart } from '@mui/x-charts/PieChart';
import { useQuery } from '@tanstack/react-query';

interface EfficiencyData {
  library: string;
  hoursSaved: number;
  projectsUsing: number;
  efficiency: number;
}

export default function EfficiencyChart() {
  const { data: efficiencyData, isLoading } = useQuery<EfficiencyData[]>({
    queryKey: ['efficiency-chart'],
    queryFn: () => fetch('/data/efficiency-chart.json').then(res => res.json()),
  });

  if (isLoading || !efficiencyData) {
    return (
      <Card sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Card>
    );
  }

  const chartData = efficiencyData.map((library, index) => ({
    id: index,
    label: library.library,
    value: library.hoursSaved,
    color: [
      '#61dafb', '#10b981', '#dd1b16', '#4fc08d', 
      '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4'
    ][index] || '#999',
  }));

  return (
    <Card sx={{ height: '100%' }}>
      <CardHeader sx={{ pb: 2 }}>
        <Typography variant="h6" component="h3" sx={{ fontWeight: 'medium' }}>
          Developer Hours Saved
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Cumulative time savings by library
        </Typography>
      </CardHeader>
      <CardContent sx={{ pt: 1 }}>
        <Box sx={{ height: 300 }}>
          <PieChart
            series={[
              {
                data: chartData,
              },
            ]}
            width={undefined}
            height={300}
          />
        </Box>
      </CardContent>
    </Card>
  );
}
