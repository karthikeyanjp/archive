import { Library, Metric } from "@/types/schema";

// Static data for GitHub Pages deployment (no backend)
export const staticLibraries: Library[] = [
  {
    id: 1,
    name: "awesome-node-lib",
    language: "Node.js",
    version: "v2.4.1",
    projectsUsing: 15432,
    monthlyDownloads: 520000,
    hoursSaved: 750000,
    githubStars: 4200,
    growthRate: 18.3,
    status: "active",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 2,
    name: "awesome-go-lib",
    language: "Golang",
    version: "v1.8.3",
    projectsUsing: 9141,
    monthlyDownloads: 327000,
    hoursSaved: 450000,
    githubStars: 2800,
    growthRate: 12.1,
    status: "active",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

export const staticMetrics: Metric[] = [
  // Node.js library metrics
  { id: 1, libraryId: 1, month: "Jan", projects: 1200, downloads: 45000, hoursSaved: 62500, createdAt: new Date() },
  { id: 2, libraryId: 1, month: "Feb", projects: 1450, downloads: 48000, hoursSaved: 65000, createdAt: new Date() },
  { id: 3, libraryId: 1, month: "Mar", projects: 1680, downloads: 52000, hoursSaved: 68000, createdAt: new Date() },
  { id: 4, libraryId: 1, month: "Apr", projects: 2100, downloads: 55000, hoursSaved: 72000, createdAt: new Date() },
  { id: 5, libraryId: 1, month: "May", projects: 2400, downloads: 58000, hoursSaved: 75000, createdAt: new Date() },
  { id: 6, libraryId: 1, month: "Jun", projects: 2800, downloads: 62000, hoursSaved: 78000, createdAt: new Date() },
  { id: 7, libraryId: 1, month: "Jul", projects: 3200, downloads: 65000, hoursSaved: 82000, createdAt: new Date() },
  { id: 8, libraryId: 1, month: "Aug", projects: 3600, downloads: 68000, hoursSaved: 85000, createdAt: new Date() },
  { id: 9, libraryId: 1, month: "Sep", projects: 4100, downloads: 72000, hoursSaved: 88000, createdAt: new Date() },
  { id: 10, libraryId: 1, month: "Oct", projects: 4500, downloads: 75000, hoursSaved: 92000, createdAt: new Date() },
  { id: 11, libraryId: 1, month: "Nov", projects: 4800, downloads: 78000, hoursSaved: 95000, createdAt: new Date() },
  { id: 12, libraryId: 1, month: "Dec", projects: 5200, downloads: 82000, hoursSaved: 98000, createdAt: new Date() },
  
  // Golang library metrics
  { id: 13, libraryId: 2, month: "Jan", projects: 800, downloads: 28000, hoursSaved: 37500, createdAt: new Date() },
  { id: 14, libraryId: 2, month: "Feb", projects: 950, downloads: 30000, hoursSaved: 39000, createdAt: new Date() },
  { id: 15, libraryId: 2, month: "Mar", projects: 1100, downloads: 32000, hoursSaved: 41000, createdAt: new Date() },
  { id: 16, libraryId: 2, month: "Apr", projects: 1300, downloads: 34000, hoursSaved: 43000, createdAt: new Date() },
  { id: 17, libraryId: 2, month: "May", projects: 1500, downloads: 36000, hoursSaved: 45000, createdAt: new Date() },
  { id: 18, libraryId: 2, month: "Jun", projects: 1750, downloads: 38000, hoursSaved: 47000, createdAt: new Date() },
  { id: 19, libraryId: 2, month: "Jul", projects: 2000, downloads: 40000, hoursSaved: 49000, createdAt: new Date() },
  { id: 20, libraryId: 2, month: "Aug", projects: 2200, downloads: 42000, hoursSaved: 51000, createdAt: new Date() },
  { id: 21, libraryId: 2, month: "Sep", projects: 2450, downloads: 44000, hoursSaved: 53000, createdAt: new Date() },
  { id: 22, libraryId: 2, month: "Oct", projects: 2700, downloads: 46000, hoursSaved: 55000, createdAt: new Date() },
  { id: 23, libraryId: 2, month: "Nov", projects: 2900, downloads: 48000, hoursSaved: 57000, createdAt: new Date() },
  { id: 24, libraryId: 2, month: "Dec", projects: 3100, downloads: 50000, hoursSaved: 59000, createdAt: new Date() },
];

export const getTotalProjects = () => staticLibraries.reduce((sum, lib) => sum + lib.projectsUsing, 0);
export const getTotalHoursSaved = () => staticLibraries.reduce((sum, lib) => sum + lib.hoursSaved, 0);
export const getTotalMonthlyDownloads = () => staticLibraries.reduce((sum, lib) => sum + lib.monthlyDownloads, 0);
export const getActiveLibrariesCount = () => staticLibraries.filter(lib => lib.status === "active").length;

export const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(0) + "K";
  }
  return num.toString();
};

export const formatLargeNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M+";
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(0) + "K";
  }
  return num.toLocaleString();
};