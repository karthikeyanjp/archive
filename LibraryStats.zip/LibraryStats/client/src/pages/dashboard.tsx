import { Box, Container, Typography, AppBar, Toolbar, IconButton, useMediaQuery, useTheme, CircularProgress, Alert } from '@mui/material';
import { Menu as MenuIcon, Assessment, Schedule, LibraryBooks, CloudDownload } from '@mui/icons-material';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Sidebar from "@/components/sidebar";
import MetricCard from "@/components/metric-card";
import LibraryCard from "@/components/library-card";
import UsageChart from "@/components/usage-chart";
import EfficiencyChart from "@/components/efficiency-chart";
import MetricsTable from "@/components/metrics-table";
import { Library } from "@shared/schema";
import { formatLargeNumber } from "@/lib/static-data";

export default function Dashboard() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const { data: libraries, isLoading, error } = useQuery<Library[]>({
    queryKey: ['libraries'],
    queryFn: () => fetch('/data/libraries.json').then(res => res.json()),
  });

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  // Calculate totals from real data
  const totalProjects = libraries?.reduce((sum, lib) => sum + lib.projectsUsing, 0) || 0;
  const totalHoursSaved = libraries?.reduce((sum, lib) => sum + lib.hoursSaved, 0) || 0;
  const totalMonthlyDownloads = libraries?.reduce((sum, lib) => sum + lib.monthlyDownloads, 0) || 0;
  const activeLibrariesCount = libraries?.filter(lib => lib.status === "active").length || 0;

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', p: 3 }}>
        <Alert severity="error">
          Failed to load dashboard data. Please try again later.
        </Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'grey.50' }}>
      <AppBar
        position="fixed"
        sx={{
          width: { md: `calc(100% - 240px)` },
          ml: { md: `240px` },
          display: { md: 'none' }
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { md: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div">
            LibraryStats
          </Typography>
        </Toolbar>
      </AppBar>

      <Sidebar mobileOpen={mobileOpen} onClose={handleDrawerToggle} />
      
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          ml: { md: '240px' },
          mt: { xs: 8, md: 0 }
        }}
      >
        <Container maxWidth="xl">
          {/* Page Header */}
          <Box sx={{ mb: 4 }}>
            <Typography variant="h3" component="h1" gutterBottom sx={{ fontWeight: 'bold', color: 'text.primary' }}>
              Library Performance Dashboard
            </Typography>
            <Typography variant="body1" color="text.secondary">
              Track usage statistics, adoption metrics, and developer impact across your open source libraries.
            </Typography>
          </Box>

          {/* Overview Stats Cards */}
          <Box sx={{ 
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', lg: '1fr 1fr 1fr 1fr' },
            gap: 3,
            mb: 4
          }}>
            <MetricCard
              title="Total Projects"
              value={formatLargeNumber(totalProjects)}
              trend="+12.5% from last month"
              icon={Assessment}
              color="primary"
            />
            <MetricCard
              title="Hours Saved"
              value={formatLargeNumber(totalHoursSaved)}
              trend="+8.3% from last month"
              icon={Schedule}
              color="success"
            />
            <MetricCard
              title="Active Libraries"
              value={activeLibrariesCount.toString()}
              description="Node.js & Golang"
              icon={LibraryBooks}
              color="warning"
            />
            <MetricCard
              title="Monthly Downloads"
              value={formatLargeNumber(totalMonthlyDownloads)}
              trend="+15.7% from last month"
              icon={CloudDownload}
              color="secondary"
            />
          </Box>

          {/* Library Comparison Section */}
          <Box sx={{ 
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' },
            gap: 3,
            mb: 4
          }}>
            {libraries?.map((library) => (
              <LibraryCard key={library.id} library={library} />
            ))}
          </Box>

          {/* Charts Section */}
          <Box sx={{ 
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' },
            gap: 3,
            mb: 4
          }}>
            <UsageChart />
            <EfficiencyChart />
          </Box>

          {/* Detailed Metrics Table */}
          <MetricsTable />

          {/* Footer */}
          <Box sx={{ mt: 4, pt: 4, borderTop: 1, borderColor: 'divider' }}>
            <Typography variant="body2" color="text.secondary" align="center">
              Last updated: December 15, 2024 at 3:42 PM
            </Typography>
          </Box>
        </Container>
      </Box>
    </Box>
  );
}
