// Simple script to start Vite development server for static site
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log('Starting Vite development server for static dashboard...');

const vite = spawn('npx', [
  'vite', 
  '--config', 'vite.config.static.ts',
  '--host', 
  '--port', '5000'
], {
  cwd: dirname(__dirname),
  stdio: 'inherit'
});

vite.on('close', (code) => {
  console.log(`Vite server exited with code ${code}`);
});

process.on('SIGINT', () => {
  vite.kill();
  process.exit();
});