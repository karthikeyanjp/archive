# Library Stats Dashboard

A React dashboard showcasing Node.js and Golang library adoption metrics with comprehensive analytics and project insights.

## Features

- **Dashboard Overview**: Summary metrics showing total projects, hours saved, downloads, and active libraries
- **Interactive Charts**: Visual representations of usage trends and efficiency data
- **Library Cards**: Detailed information about each library including GitHub stars, growth rates, and status
- **Responsive Design**: Mobile-friendly interface using Material-UI components
- **Static Deployment**: Optimized for GitHub Pages with pre-built data

## Technologies Used

- React 18 with TypeScript
- Material-UI (MUI) for components and styling
- MUI X Charts for data visualization
- Vite for build tooling
- Wouter for client-side routing

## Development

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

The application will be available at `http://localhost:5000`

## Deployment to GitHub Pages

This project is configured for automatic deployment to GitHub Pages using GitHub Actions.

### Setup Instructions

1. **Fork or clone this repository**

2. **Enable GitHub Pages**:
   - Go to your repository settings
   - Navigate to "Pages" section
   - Set source to "GitHub Actions"

3. **Configure repository secrets** (if needed):
   - The current setup uses static data and doesn't require API keys
   - For future API integrations, add secrets in Settings > Secrets and variables > Actions

4. **Automatic Deployment**:
   - Push changes to the `main` branch
   - GitHub Actions will automatically build and deploy
   - The site will be available at `https://yourusername.github.io/repository-name/`

### Manual Build for GitHub Pages

To build the static files locally:

```bash
npx vite build --config vite.config.pages.ts
```

The built files will be in the `dist` directory.

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── lib/           # Utilities and data
│   │   └── App.tsx        # Main application component
├── .github/workflows/     # GitHub Actions for deployment
├── vite.config.pages.ts   # Vite config for static build
└── README.md
```

## Data Sources

Currently uses static mock data for demonstration purposes. The application showcases:

- **Node.js Library**: 15,432 projects using, 520K monthly downloads, 750K hours saved
- **Golang Library**: 9,141 projects using, 327K monthly downloads, 450K hours saved

## Customization

To add your own library data:

1. Edit `client/src/lib/static-data.ts`
2. Update the `staticLibraries` and `staticMetrics` arrays
3. Rebuild and redeploy

## License

MIT License - feel free to use this project as a template for your own library analytics dashboard.