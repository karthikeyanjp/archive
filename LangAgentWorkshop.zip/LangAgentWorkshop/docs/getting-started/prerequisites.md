# Prerequisites

Before diving into building enterprise-grade AI agents, let's ensure you have the necessary background knowledge, tools, and environment setup. This page will help you assess your readiness and prepare for the workshop.

## 📋 Knowledge Requirements

### Essential Programming Skills

#### Python Proficiency (Required)
You should be comfortable with:

- **Basic Syntax** - Variables, data types, operators
- **Control Structures** - If statements, loops, exception handling
- **Functions and Classes** - Function definition, OOP concepts
- **Modules and Packages** - Import statements, package organization
- **Data Structures** - Lists, dictionaries, sets, tuples

**Self-Assessment Test:**
```python
# Can you understand and modify this code?
class AgentMemory:
    def __init__(self):
        self.conversations = {}
    
    def store_message(self, session_id: str, message: dict):
        if session_id not in self.conversations:
            self.conversations[session_id] = []
        self.conversations[session_id].append(message)
    
    def get_history(self, session_id: str, limit: int = 10):
        return self.conversations.get(session_id, [])[-limit:]
