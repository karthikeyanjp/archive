# LangGraph & LangChain Agents Workshop Documentation

This repository contains comprehensive documentation for building enterprise-grade AI agents using LangGraph and LangChain. The documentation is built with MkDocs and automatically deployed to GitLab Pages.

## 🚀 Live Documentation

The workshop documentation is available at: `https://your-gitlab-username.gitlab.io/langgraph-workshop`

## 📁 Repository Structure

```
├── docs/                          # Documentation source files
│   ├── getting-started/           # Workshop setup and prerequisites
│   ├── fundamentals/              # Core concepts and basics
│   ├── building-agents/           # Agent development tutorials
│   ├── supervisor-patterns/       # Multi-agent coordination
│   ├── memory-systems/            # Memory implementation guides
│   └── index.md                   # Homepage
├── mkdocs.yml                     # MkDocs configuration
├── .gitlab-ci.yml                 # GitLab CI/CD pipeline
└── README.md                      # This file
```

## 🔧 Local Development

### Prerequisites

- Python 3.9 or higher
- Git

### Setup

1. Clone the repository:
   ```bash
   git clone https://gitlab.com/your-gitlab-username/langgraph-workshop.git
   cd langgraph-workshop
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install mkdocs mkdocs-material mkdocs-git-revision-date-localized-plugin mkdocs-git-committers-plugin-2 mkdocs-minify-plugin
   ```

4. Start the development server:
   ```bash
   mkdocs serve
   ```

5. Open your browser to `http://localhost:8000`

## 🔄 GitLab Pages Deployment

The documentation is automatically deployed to GitLab Pages when changes are pushed to the `main` branch.

### Pipeline Configuration

The `.gitlab-ci.yml` file defines two stages:

1. **Build**: Validates the documentation on merge requests and development branches
2. **Deploy**: Builds and publishes to GitLab Pages on the main branch

### Setting Up Your Repository

1. **Update Configuration**: Replace `your-gitlab-username` in the following files:
   - `mkdocs.yml` (lines 4, 7, 8, 82)
   - This README.md

2. **Enable GitLab Pages**: 
   - Go to your GitLab project settings
   - Navigate to Pages section
   - Ensure Pages is enabled

3. **Configure Repository Settings**:
   - Set the default branch to `main` if not already set
   - Ensure the repository visibility allows Pages deployment

### First Deployment

1. Push your changes to the main branch:
   ```bash
   git add .
   git commit -m "Initial documentation setup"
   git push origin main
   ```

2. Check the pipeline status:
   - Go to your GitLab project
   - Navigate to CI/CD → Pipelines
   - Monitor the deployment progress

3. Access your documentation:
   - After successful deployment, visit `https://your-gitlab-username.gitlab.io/langgraph-workshop`

## 📝 Adding Content

### Creating New Pages

1. Add markdown files to the appropriate directory under `docs/`
2. Update the navigation in `mkdocs.yml` under the `nav` section
3. Use relative links to reference other pages

### Content Guidelines

- Follow the existing structure and formatting
- Include code examples where appropriate
- Add learning objectives at the beginning of each section
- Use Mermaid diagrams for architectural illustrations

### Preview Changes

Always preview your changes locally before pushing:

```bash
mkdocs serve
```

## 🔍 Troubleshooting

### Common Issues

1. **Pipeline Fails**: Check the job logs in GitLab CI/CD for specific error messages
2. **Pages Not Updating**: Ensure the pipeline completed successfully and wait a few minutes for propagation
3. **Links Broken**: Verify all internal links use relative paths and referenced files exist

### Getting Help

- Check the MkDocs documentation: https://www.mkdocs.org/
- Review Material theme docs: https://squidfunk.github.io/mkdocs-material/
- GitLab Pages documentation: https://docs.gitlab.com/ee/user/project/pages/

## 📄 License

This documentation is licensed under [Your License]. Please see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test locally with `mkdocs serve`
5. Submit a merge request

---

**Workshop Maintainer**: Your Organization  
**Last Updated**: 2024