# Tool Development

This section guides you through building the CheckCoverage and GetCopy tools that our ReAct agent will use. We'll implement these tools following LangChain's tool interface standards and include proper error handling and validation.

## 🎯 Learning Objectives

By the end of this section, you will:
- Understand LangChain tool development patterns
- Build the CheckCoverage tool for code analysis
- Create the GetCopy tool for content retrieval
- Implement proper input validation and error handling
- Add comprehensive testing for both tools
- Integrate tools with async operations

## 🔧 Tool Architecture Overview

Our tools follow LangChain's BaseTool pattern with these components:

```mermaid
graph TD
    A[Tool Input] --> B[Input Validation]
    B --> C[Authentication Check]
    C --> D[API Request]
    D --> E[Response Processing]
    E --> F[Output Formatting]
    F --> G[Tool Output]
    
    H[Error Handler] --> B
    H --> C
    H --> D
    H --> E
```

## 📝 Step 1: CheckCoverage Tool Implementation

Create the CheckCoverage tool that analyzes code coverage metrics:

```python
# src/react_agent/tools/check_coverage.py
from typing import Dict, Any, Optional, List
from langchain.tools import BaseTool
from pydantic import BaseModel, Field
import httpx
import logging
from ..config.settings import settings
from ..utils.helpers import validate_api_response

logger = logging.getLogger(__name__)

class CheckCoverageInput(BaseModel):
    """Input schema for CheckCoverage tool."""
    project_path: str = Field(description="Path to the project directory")
    test_config: str = Field(
        description="Test configuration (pytest, unittest, nose2)",
        default="pytest"
    )
    coverage_threshold: Optional[float] = Field(
        description="Minimum coverage threshold (0-100)",
        default=80.0
    )
    include_patterns: Optional[List[str]] = Field(
        description="File patterns to include in coverage analysis",
        default=None
    )
    exclude_patterns: Optional[List[str]] = Field(
        description="File patterns to exclude from coverage analysis",
        default=None
    )

class CheckCoverageTool(BaseTool):
    """Tool for analyzing code coverage metrics."""
    
    name = "check_coverage"
    description = """
    Analyzes code coverage metrics for a given project.
    
    This tool can:
    - Generate coverage reports for Python projects
    - Identify uncovered code sections
    - Provide coverage statistics and recommendations
    - Support multiple test frameworks (pytest, unittest, nose2)
    
    Input should include:
    - project_path: Path to the project directory
    - test_config: Test framework configuration
    - coverage_threshold: Minimum acceptable coverage percentage
    """
    
    args_schema = CheckCoverageInput
    
    def __init__(self):
        super().__init__()
        self.api_url = settings.checkcoverage_api_url
        self.api_key = settings.checkcoverage_api_key
        self.timeout = settings.timeout_seconds
    
    async def _arun(self, **kwargs) -> str:
        """Run the tool asynchronously."""
        try:
            # Validate input
            input_data = CheckCoverageInput(**kwargs)
            
            logger.info(f"Starting coverage analysis for {input_data.project_path}")
            
            # Prepare API request
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "project_path": input_data.project_path,
                "test_config": input_data.test_config,
                "coverage_threshold": input_data.coverage_threshold,
                "include_patterns": input_data.include_patterns or [],
                "exclude_patterns": input_data.exclude_patterns or ["*/tests/*", "*/test_*"]
            }
            
            # Make API request
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.api_url}/analyze",
                    json=payload,
                    headers=headers
                )
                response.raise_for_status()
                result = response.json()
            
            # Validate response
            if not validate_api_response(result):
                raise ValueError("Invalid API response format")
            
            # Process and format results
            coverage_data = result["data"]
            formatted_result = self._format_coverage_result(coverage_data)
            
            logger.info(f"Coverage analysis completed: {coverage_data.get('total_coverage', 0):.1f}%")
            return formatted_result
            
        except httpx.HTTPStatusError as e:
            error_msg = f"API request failed: {e.response.status_code} - {e.response.text}"
            logger.error(error_msg)
            return f"Error: Unable to analyze coverage. {error_msg}"
        
        except Exception as e:
            error_msg = f"Coverage analysis failed: {str(e)}"
            logger.error(error_msg)
            return f"Error: {error_msg}"
    
    def _run(self, **kwargs) -> str:
        """Synchronous run method (not implemented for async tool)."""
        raise NotImplementedError("This tool only supports async execution")
    
    def _format_coverage_result(self, coverage_data: Dict[str, Any]) -> str:
        """Format coverage analysis results."""
        total_coverage = coverage_data.get("total_coverage", 0)
        line_coverage = coverage_data.get("line_coverage", 0)
        branch_coverage = coverage_data.get("branch_coverage", 0)
        
        # Build formatted report
        report_lines = [
            "📊 Coverage Analysis Results",
            "=" * 40,
            f"Total Coverage: {total_coverage:.1f}%",
            f"Line Coverage: {line_coverage:.1f}%",
            f"Branch Coverage: {branch_coverage:.1f}%",
            ""
        ]
        
        # Add threshold check
        threshold = coverage_data.get("threshold", 80.0)
        if total_coverage >= threshold:
            report_lines.append(f"✅ Coverage meets threshold ({threshold}%)")
        else:
            report_lines.append(f"❌ Coverage below threshold ({threshold}%)")
            report_lines.append(f"   Need {threshold - total_coverage:.1f}% more coverage")
        
        # Add uncovered sections if any
        uncovered_lines = coverage_data.get("uncovered_lines", [])
        if uncovered_lines:
            report_lines.extend([
                "",
                "🔍 Uncovered Code Sections:",
                "-" * 30
            ])
            
            for file_info in uncovered_lines[:5]:  # Limit to first 5 files
                file_path = file_info.get("file", "Unknown")
                lines = file_info.get("lines", [])
                report_lines.append(f"📄 {file_path}")
                report_lines.append(f"   Lines: {', '.join(map(str, lines[:10]))}")
                if len(lines) > 10:
                    report_lines.append(f"   ... and {len(lines) - 10} more lines")
                report_lines.append("")
        
        # Add recommendations
        recommendations = coverage_data.get("recommendations", [])
        if recommendations:
            report_lines.extend([
                "💡 Recommendations:",
                "-" * 20
            ])
            for rec in recommendations[:3]:  # Limit to top 3
                report_lines.append(f"• {rec}")
        
        return "\n".join(report_lines)
```

## 📄 Step 2: GetCopy Tool Implementation

Create the GetCopy tool for content retrieval:

```python
# src/react_agent/tools/get_copy.py
from typing import Dict, Any, Optional, List
from langchain.tools import BaseTool
from pydantic import BaseModel, Field
import httpx
import logging
from datetime import datetime
from ..config.settings import settings
from ..utils.helpers import validate_api_response

logger = logging.getLogger(__name__)

class GetCopyInput(BaseModel):
    """Input schema for GetCopy tool."""
    content_id: str = Field(description="Unique identifier for the content piece")
    template_type: str = Field(
        description="Type of content template (email_campaign, landing_page, social_post, etc.)"
    )
    target_audience: str = Field(
        description="Target audience segment (enterprise_customers, small_business, developers, etc.)"
    )
    language: Optional[str] = Field(
        description="Content language code (en, es, fr, etc.)",
        default="en"
    )
    format: Optional[str] = Field(
        description="Output format (html, text, markdown)",
        default="text"
    )
    include_metadata: Optional[bool] = Field(
        description="Include content metadata in response",
        default=True
    )

class GetCopyTool(BaseTool):
    """Tool for retrieving marketing copy and content."""
    
    name = "get_copy"
    description = """
    Retrieves marketing copy and content from the content management system.
    
    This tool can:
    - Fetch approved marketing copy by content ID
    - Filter content by template type and target audience
    - Return content in multiple formats (HTML, text, markdown)
    - Include metadata like approval status and version info
    
    Input should include:
    - content_id: Unique identifier for the content
    - template_type: Type of content template
    - target_audience: Target audience segment
    """
    
    args_schema = GetCopyInput
    
    def __init__(self):
        super().__init__()
        self.api_url = settings.getcopy_api_url
        self.api_key = settings.getcopy_api_key
        self.timeout = settings.timeout_seconds
    
    async def _arun(self, **kwargs) -> str:
        """Run the tool asynchronously."""
        try:
            # Validate input
            input_data = GetCopyInput(**kwargs)
            
            logger.info(f"Retrieving copy for content_id: {input_data.content_id}")
            
            # Prepare API request
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            params = {
                "content_id": input_data.content_id,
                "template_type": input_data.template_type,
                "target_audience": input_data.target_audience,
                "language": input_data.language,
                "format": input_data.format,
                "include_metadata": input_data.include_metadata
            }
            
            # Make API request
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.api_url}/content",
                    params=params,
                    headers=headers
                )
                response.raise_for_status()
                result = response.json()
            
            # Validate response
            if not validate_api_response(result):
                raise ValueError("Invalid API response format")
            
            # Process and format results
            content_data = result["data"]
            formatted_result = self._format_copy_result(content_data, input_data)
            
            logger.info(f"Copy retrieved successfully for {input_data.content_id}")
            return formatted_result
            
        except httpx.HTTPStatusError as e:
            error_msg = f"API request failed: {e.response.status_code} - {e.response.text}"
            logger.error(error_msg)
            return f"Error: Unable to retrieve copy. {error_msg}"
        
        except Exception as e:
            error_msg = f"Copy retrieval failed: {str(e)}"
            logger.error(error_msg)
            return f"Error: {error_msg}"
    
    def _run(self, **kwargs) -> str:
        """Synchronous run method (not implemented for async tool)."""
        raise NotImplementedError("This tool only supports async execution")
    
    def _format_copy_result(self, content_data: Dict[str, Any], input_data: GetCopyInput) -> str:
        """Format copy retrieval results."""
        content = content_data.get("content", {})
        metadata = content_data.get("metadata", {})
        
        # Build formatted response
        result_lines = [
            "📝 Content Retrieved",
            "=" * 30,
            f"Content ID: {input_data.content_id}",
            f"Template Type: {input_data.template_type}",
            f"Target Audience: {input_data.target_audience}",
            ""
        ]
        
        # Add content sections
        if isinstance(content, dict):
            for key, value in content.items():
                if value:
                    result_lines.append(f"📄 {key.title()}:")
                    result_lines.append(f"{value}")
                    result_lines.append("")
        else:
            result_lines.append(f"📄 Content:")
            result_lines.append(f"{content}")
            result_lines.append("")
        
        # Add metadata if included
        if input_data.include_metadata and metadata:
            result_lines.extend([
                "ℹ️ Metadata:",
                "-" * 15
            ])
            
            # Format common metadata fields
            if "created_at" in metadata:
                created_date = datetime.fromisoformat(
                    metadata["created_at"].replace("Z", "+00:00")
                ).strftime("%Y-%m-%d %H:%M")
                result_lines.append(f"Created: {created_date}")
            
            if "approved" in metadata:
                status = "✅ Approved" if metadata["approved"] else "⏳ Pending Approval"
                result_lines.append(f"Status: {status}")
            
            if "version" in metadata:
                result_lines.append(f"Version: {metadata['version']}")
            
            if "author" in metadata:
                result_lines.append(f"Author: {metadata['author']}")
            
            # Add any additional metadata
            for key, value in metadata.items():
                if key not in ["created_at", "approved", "version", "author"]:
                    result_lines.append(f"{key.title()}: {value}")
        
        return "\n".join(result_lines)
```

## 🧪 Step 3: Tool Testing

Create comprehensive tests for both tools:

```python
# tests/unit/test_tools.py
import pytest
from unittest.mock import AsyncMock, Mock, patch
import httpx
from src.react_agent.tools.check_coverage import CheckCoverageTool
from src.react_agent.tools.get_copy import GetCopyTool

class TestCheckCoverageTool:
    """Test cases for CheckCoverage tool."""
    
    @pytest.fixture
    def coverage_tool(self):
        return CheckCoverageTool()
    
    @pytest.fixture
    def mock_coverage_response(self):
        return {
            "status": "success",
            "data": {
                "total_coverage": 85.5,
                "line_coverage": 87.2,
                "branch_coverage": 83.8,
                "threshold": 80.0,
                "uncovered_lines": [
                    {"file": "src/module.py", "lines": [42, 43, 56]},
                    {"file": "src/utils.py", "lines": [12, 28]}
                ],
                "recommendations": [
                    "Add tests for error handling paths",
                    "Test edge cases in data validation",
                    "Cover exception scenarios"
                ]
            }
        }
    
    @pytest.mark.asyncio
    async def test_coverage_analysis_success(self, coverage_tool, mock_coverage_response):
        """Test successful coverage analysis."""
        
        with patch('httpx.AsyncClient') as mock_client:
            # Setup mock response
            mock_response = Mock()
            mock_response.json.return_value = mock_coverage_response
            mock_response.raise_for_status = Mock()
            
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                return_value=mock_response
            )
            
            # Run tool
            result = await coverage_tool._arun(
                project_path="/test/project",
                test_config="pytest",
                coverage_threshold=80.0
            )
            
            # Verify results
            assert "📊 Coverage Analysis Results" in result
            assert "Total Coverage: 85.5%" in result
            assert "✅ Coverage meets threshold" in result
            assert "src/module.py" in result
    
    @pytest.mark.asyncio
    async def test_coverage_analysis_api_error(self, coverage_tool):
        """Test handling of API errors."""
        
        with patch('httpx.AsyncClient') as mock_client:
            # Setup mock error
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                side_effect=httpx.HTTPStatusError(
                    "Server Error",
                    request=Mock(),
                    response=Mock(status_code=500, text="Internal Server Error")
                )
            )
            
            # Run tool
            result = await coverage_tool._arun(
                project_path="/test/project",
                test_config="pytest"
            )
            
            # Verify error handling
            assert "Error: Unable to analyze coverage" in result
            assert "500" in result

class TestGetCopyTool:
    """Test cases for GetCopy tool."""
    
    @pytest.fixture
    def copy_tool(self):
        return GetCopyTool()
    
    @pytest.fixture
    def mock_copy_response(self):
        return {
            "status": "success",
            "data": {
                "content": {
                    "subject": "Unlock Enterprise AI Solutions",
                    "body": "Transform your business with our advanced AI platform. Discover how industry leaders are achieving 40% efficiency gains.",
                    "cta": "Schedule Demo"
                },
                "metadata": {
                    "created_at": "2024-01-15T10:30:00Z",
                    "approved": True,
                    "version": "1.2",
                    "author": "Content Team"
                }
            }
        }
    
    @pytest.mark.asyncio
    async def test_copy_retrieval_success(self, copy_tool, mock_copy_response):
        """Test successful copy retrieval."""
        
        with patch('httpx.AsyncClient') as mock_client:
            # Setup mock response
            mock_response = Mock()
            mock_response.json.return_value = mock_copy_response
            mock_response.raise_for_status = Mock()
            
            mock_client.return_value.__aenter__.return_value.get = AsyncMock(
                return_value=mock_response
            )
            
            # Run tool
            result = await copy_tool._arun(
                content_id="PROMO_001",
                template_type="email_campaign",
                target_audience="enterprise_customers"
            )
            
            # Verify results
            assert "📝 Content Retrieved" in result
            assert "PROMO_001" in result
            assert "Unlock Enterprise AI Solutions" in result
            assert "✅ Approved" in result
    
    @pytest.mark.asyncio
    async def test_copy_retrieval_without_metadata(self, copy_tool, mock_copy_response):
        """Test copy retrieval without metadata."""
        
        with patch('httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.json.return_value = mock_copy_response
            mock_response.raise_for_status = Mock()
            
            mock_client.return_value.__aenter__.return_value.get = AsyncMock(
                return_value=mock_response
            )
            
            # Run tool without metadata
            result = await copy_tool._arun(
                content_id="PROMO_001",
                template_type="email_campaign",
                target_audience="enterprise_customers",
                include_metadata=False
            )
            
            # Verify metadata is not included
            assert "📝 Content Retrieved" in result
            assert "ℹ️ Metadata:" not in result
```

## 📦 Step 4: Tool Registration

Create a tool registry for easy management:

```python
# src/react_agent/tools/__init__.py
from .check_coverage import CheckCoverageTool
from .get_copy import GetCopyTool
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class ToolRegistry:
    """Registry for managing available tools."""
    
    def __init__(self):
        self._tools = {}
        self._initialize_tools()
    
    def _initialize_tools(self):
        """Initialize and register all available tools."""
        try:
            # Register CheckCoverage tool
            coverage_tool = CheckCoverageTool()
            self._tools[coverage_tool.name] = coverage_tool
            logger.info(f"Registered tool: {coverage_tool.name}")
            
            # Register GetCopy tool
            copy_tool = GetCopyTool()
            self._tools[copy_tool.name] = copy_tool
            logger.info(f"Registered tool: {copy_tool.name}")
            
        except Exception as e:
            logger.error(f"Failed to initialize tools: {e}")
            raise
    
    def get_tool(self, name: str):
        """Get a tool by name."""
        return self._tools.get(name)
    
    def get_all_tools(self) -> List[Any]:
        """Get all registered tools."""
        return list(self._tools.values())
    
    def get_tool_names(self) -> List[str]:
        """Get names of all registered tools."""
        return list(self._tools.keys())
    
    def get_tool_descriptions(self) -> Dict[str, str]:
        """Get descriptions of all tools."""
        return {
            name: tool.description 
            for name, tool in self._tools.items()
        }

# Global tool registry instance
tool_registry = ToolRegistry()

# Convenience exports
__all__ = [
    "CheckCoverageTool",
    "GetCopyTool",
    "ToolRegistry",
    "tool_registry"
]
```

## ✅ Tool Development Complete

You've now created:

- ✅ CheckCoverage tool with comprehensive coverage analysis
- ✅ GetCopy tool for content management integration
- ✅ Proper input validation and error handling
- ✅ Async support for both tools
- ✅ Comprehensive test coverage
- ✅ Tool registry for management

## 🧪 Testing Your Tools

Run the tool tests to verify everything works:

```bash
# Run tool-specific tests
poetry run pytest tests/unit/test_tools.py -v

# Test tools with the test script
poetry run python scripts/test_tools.py
```

## 🔄 Next Steps

Your tools are ready! Now proceed to [Agent Implementation](agent-implementation.md) to integrate these tools with LangGraph's create-react-agent and build the complete ReAct agent system.