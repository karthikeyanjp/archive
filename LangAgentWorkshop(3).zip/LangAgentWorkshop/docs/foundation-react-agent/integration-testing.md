# Integration & Testing

This section covers comprehensive testing strategies for your Foundation ReAct Agent, including integration tests, performance validation, and production readiness verification.

## 🎯 Learning Objectives

By the end of this section, you will:
- Implement comprehensive integration testing strategies
- Validate tool integrations with real API endpoints
- Perform load testing and performance validation
- Set up automated testing pipelines
- Debug common integration issues
- Prepare the agent for production deployment

## 🧪 Testing Strategy Overview

Our testing approach covers multiple layers:

```mermaid
graph TD
    A[Unit Tests] --> B[Integration Tests]
    B --> C[End-to-End Tests]
    C --> D[Performance Tests]
    D --> E[Security Tests]
    E --> F[Production Validation]
    
    G[Tool Tests] --> B
    H[Agent Logic Tests] --> B
    I[API Integration Tests] --> C
    J[User Journey Tests] --> C
```

## 📝 Step 1: Integration Test Implementation

Create comprehensive integration tests:

```python
# tests/integration/test_full_agent_workflow.py
import pytest
import asyncio
from unittest.mock import patch, AsyncMock
import httpx
from src.react_agent.agent import ReactAgentWithMonitoring
from src.react_agent.config.settings import settings

class TestFullAgentWorkflow:
    """End-to-end integration tests for the complete agent workflow."""
    
    @pytest.fixture
    async def agent(self):
        """Create an agent instance for testing."""
        with patch('src.react_agent.agent.ChatOpenAI') as mock_llm:
            # Mock LLM responses for testing
            mock_llm.return_value.ainvoke = AsyncMock()
            agent = ReactAgentWithMonitoring()
            yield agent
    
    @pytest.mark.asyncio
    async def test_coverage_analysis_workflow(self, agent):
        """Test complete coverage analysis workflow."""
        
        # Mock the coverage API response
        mock_coverage_response = {
            "status": "success",
            "data": {
                "total_coverage": 78.5,
                "line_coverage": 80.2,
                "branch_coverage": 76.8,
                "threshold": 80.0,
                "uncovered_lines": [
                    {"file": "src/auth.py", "lines": [45, 46, 52]},
                    {"file": "src/database.py", "lines": [123, 156]}
                ],
                "recommendations": [
                    "Add tests for authentication error scenarios",
                    "Test database connection failures"
                ]
            }
        }
        
        with patch('httpx.AsyncClient') as mock_client:
            mock_response = AsyncMock()
            mock_response.json.return_value = mock_coverage_response
            mock_response.raise_for_status = AsyncMock()
            
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                return_value=mock_response
            )
            
            # Mock LLM to simulate agent workflow
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "I'll analyze the code coverage for your project. Based on the coverage analysis, your project has 78.5% total coverage, which is below the 80% threshold. The main areas needing attention are authentication error scenarios and database connection failures."}]
            })
            
            # Test the workflow
            result = await agent.run_with_monitoring(
                "Check code coverage for my Python project at /app/myproject"
            )
            
            # Validate response
            assert result["status"] == "success"
            assert "78.5%" in result["response"]
            assert "authentication" in result["response"].lower()
            assert result["response_time"] > 0
    
    @pytest.mark.asyncio
    async def test_content_retrieval_workflow(self, agent):
        """Test complete content retrieval workflow."""
        
        # Mock the content API response
        mock_content_response = {
            "status": "success",
            "data": {
                "content": {
                    "subject": "Transform Your Business with AI",
                    "body": "Discover how our enterprise AI platform can revolutionize your operations and drive unprecedented growth.",
                    "cta": "Request Demo"
                },
                "metadata": {
                    "created_at": "2024-01-20T14:30:00Z",
                    "approved": True,
                    "version": "2.1",
                    "author": "Marketing Team"
                }
            }
        }
        
        with patch('httpx.AsyncClient') as mock_client:
            mock_response = AsyncMock()
            mock_response.json.return_value = mock_content_response
            mock_response.raise_for_status = AsyncMock()
            
            mock_client.return_value.__aenter__.return_value.get = AsyncMock(
                return_value=mock_response
            )
            
            # Mock LLM response
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "I've retrieved the marketing content for campaign PROMO_2024. The subject line is 'Transform Your Business with AI' and it's approved for use with enterprise customers."}]
            })
            
            # Test the workflow
            result = await agent.run_with_monitoring(
                "Get marketing copy for campaign PROMO_2024 targeting enterprise customers"
            )
            
            # Validate response
            assert result["status"] == "success"
            assert "Transform Your Business" in result["response"]
            assert "approved" in result["response"].lower()
    
    @pytest.mark.asyncio
    async def test_multi_tool_workflow(self, agent):
        """Test workflow that uses multiple tools in sequence."""
        
        # Mock both API responses
        coverage_response = {
            "status": "success",
            "data": {"total_coverage": 92.3, "threshold": 90.0}
        }
        
        content_response = {
            "status": "success", 
            "data": {
                "content": {"subject": "High Quality Code", "body": "Our platform maintains 92%+ code coverage"},
                "metadata": {"approved": True}
            }
        }
        
        with patch('httpx.AsyncClient') as mock_client:
            # Setup mock responses for different endpoints
            async def mock_request(*args, **kwargs):
                mock_resp = AsyncMock()
                mock_resp.raise_for_status = AsyncMock()
                
                if "analyze" in str(kwargs.get('json', {}).get('project_path', '')):
                    mock_resp.json.return_value = coverage_response
                else:
                    mock_resp.json.return_value = content_response
                
                return mock_resp
            
            mock_client.return_value.__aenter__.return_value.post = mock_request
            mock_client.return_value.__aenter__.return_value.get = mock_request
            
            # Mock complex LLM workflow
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "I checked your code coverage (92.3% - excellent!) and found relevant marketing content that highlights your quality standards."}]
            })
            
            result = await agent.run_with_monitoring(
                "Check our code quality metrics and find marketing content that showcases our development standards"
            )
            
            assert result["status"] == "success"
            assert "92.3%" in result["response"]
    
    @pytest.mark.asyncio
    async def test_error_recovery_workflow(self, agent):
        """Test agent's ability to handle and recover from errors."""
        
        with patch('httpx.AsyncClient') as mock_client:
            # First call fails, second succeeds
            call_count = 0
            
            async def mock_failing_request(*args, **kwargs):
                nonlocal call_count
                call_count += 1
                
                if call_count == 1:
                    raise httpx.HTTPStatusError(
                        "Service Unavailable",
                        request=AsyncMock(),
                        response=AsyncMock(status_code=503, text="Service temporarily unavailable")
                    )
                else:
                    mock_resp = AsyncMock()
                    mock_resp.json.return_value = {
                        "status": "success",
                        "data": {"total_coverage": 85.0}
                    }
                    mock_resp.raise_for_status = AsyncMock()
                    return mock_resp
            
            mock_client.return_value.__aenter__.return_value.post = mock_failing_request
            
            # Mock agent handling error and retry
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "I encountered a temporary service issue but was able to retrieve your coverage data: 85.0%"}]
            })
            
            result = await agent.run_with_monitoring(
                "Analyze code coverage for my project"
            )
            
            # Should still succeed despite initial failure
            assert result["status"] == "success"
            assert "85.0%" in result["response"]
```

## 🔧 Step 2: Performance Testing

Create performance validation tests:

```python
# tests/performance/test_agent_performance.py
import pytest
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor
from src.react_agent.agent import ReactAgentWithMonitoring

class TestAgentPerformance:
    """Performance tests for the ReAct agent."""
    
    @pytest.fixture
    async def agent(self):
        with patch('src.react_agent.agent.ChatOpenAI') as mock_llm:
            agent = ReactAgentWithMonitoring()
            # Mock fast responses for performance testing
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "Quick response"}]
            })
            yield agent
    
    @pytest.mark.asyncio
    async def test_response_time_benchmark(self, agent):
        """Test response time benchmarks."""
        
        response_times = []
        
        for i in range(10):
            start_time = time.time()
            result = await agent.run_with_monitoring(f"Test query {i}")
            end_time = time.time()
            
            response_times.append(end_time - start_time)
            assert result["status"] == "success"
        
        # Performance assertions
        avg_response_time = sum(response_times) / len(response_times)
        max_response_time = max(response_times)
        
        assert avg_response_time < 2.0, f"Average response time {avg_response_time:.2f}s exceeds 2s threshold"
        assert max_response_time < 5.0, f"Maximum response time {max_response_time:.2f}s exceeds 5s threshold"
        
        # Check 95th percentile
        sorted_times = sorted(response_times)
        p95_time = sorted_times[int(0.95 * len(sorted_times))]
        assert p95_time < 3.0, f"95th percentile response time {p95_time:.2f}s exceeds 3s threshold"
    
    @pytest.mark.asyncio
    async def test_concurrent_requests(self, agent):
        """Test handling of concurrent requests."""
        
        async def make_request(request_id):
            return await agent.run_with_monitoring(f"Concurrent request {request_id}")
        
        # Create 20 concurrent requests
        tasks = [make_request(i) for i in range(20)]
        
        start_time = time.time()
        results = await asyncio.gather(*tasks)
        end_time = time.time()
        
        # Validate all requests succeeded
        success_count = sum(1 for result in results if result["status"] == "success")
        assert success_count == 20, f"Only {success_count}/20 concurrent requests succeeded"
        
        # Check overall throughput
        total_time = end_time - start_time
        throughput = len(results) / total_time
        assert throughput > 5.0, f"Throughput {throughput:.2f} requests/sec below threshold"
    
    @pytest.mark.asyncio
    async def test_memory_usage_stability(self, agent):
        """Test memory usage stability over extended usage."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Run many requests to test for memory leaks
        for i in range(100):
            await agent.run_with_monitoring(f"Memory test {i}")
            
            if i % 25 == 0:  # Check every 25 requests
                current_memory = process.memory_info().rss / 1024 / 1024
                memory_growth = current_memory - initial_memory
                
                # Allow reasonable memory growth but catch leaks
                assert memory_growth < 100, f"Memory growth {memory_growth:.1f}MB suggests potential leak"
```

## 🔍 Step 3: Real API Integration Testing

Test with actual API endpoints when credentials are available:

```python
# tests/integration/test_real_api_integration.py
import pytest
import os
from src.react_agent.tools.check_coverage import CheckCoverageTool
from src.react_agent.tools.get_copy import GetCopyTool

@pytest.mark.skipif(
    not os.getenv("CHECKCOVERAGE_API_KEY"),
    reason="CheckCoverage API key not available"
)
class TestRealCheckCoverageAPI:
    """Tests against real CheckCoverage API (requires valid credentials)."""
    
    @pytest.fixture
    def coverage_tool(self):
        return CheckCoverageTool()
    
    @pytest.mark.asyncio
    async def test_real_coverage_analysis(self, coverage_tool):
        """Test with real API endpoint."""
        
        # Use a public test project or your own
        result = await coverage_tool._arun(
            project_path="/test/sample-project",
            test_config="pytest",
            coverage_threshold=75.0
        )
        
        # Validate real response structure
        assert "Coverage Analysis Results" in result
        assert "%" in result  # Should contain percentage
        assert not result.startswith("Error:")

@pytest.mark.skipif(
    not os.getenv("GETCOPY_API_KEY"),
    reason="GetCopy API key not available"  
)
class TestRealGetCopyAPI:
    """Tests against real GetCopy API (requires valid credentials)."""
    
    @pytest.fixture
    def copy_tool(self):
        return GetCopyTool()
    
    @pytest.mark.asyncio
    async def test_real_content_retrieval(self, copy_tool):
        """Test with real API endpoint."""
        
        result = await copy_tool._arun(
            content_id="TEST_001",
            template_type="email_campaign", 
            target_audience="developers"
        )
        
        # Validate real response
        assert "Content Retrieved" in result
        assert not result.startswith("Error:")
```

## 🚨 Step 4: Error Handling Validation

Test comprehensive error scenarios:

```python
# tests/integration/test_error_scenarios.py
import pytest
from unittest.mock import patch, AsyncMock
import httpx
from src.react_agent.agent import ReactAgentWithMonitoring

class TestErrorScenarios:
    """Test various error scenarios and recovery mechanisms."""
    
    @pytest.fixture
    async def agent(self):
        with patch('src.react_agent.agent.ChatOpenAI'):
            agent = ReactAgentWithMonitoring()
            yield agent
    
    @pytest.mark.asyncio
    async def test_api_timeout_handling(self, agent):
        """Test handling of API timeouts."""
        
        with patch('httpx.AsyncClient') as mock_client:
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                side_effect=httpx.TimeoutException("Request timeout")
            )
            
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "I encountered a timeout while trying to analyze coverage. Please try again later."}]
            })
            
            result = await agent.run_with_monitoring("Check coverage")
            
            assert result["status"] == "success"  # Agent handled gracefully
            assert "timeout" in result["response"].lower()
    
    @pytest.mark.asyncio  
    async def test_invalid_api_response(self, agent):
        """Test handling of malformed API responses."""
        
        with patch('httpx.AsyncClient') as mock_client:
            mock_response = AsyncMock()
            mock_response.json.return_value = {"invalid": "response"}  # Missing required fields
            mock_response.raise_for_status = AsyncMock()
            
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                return_value=mock_response
            )
            
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "I received an invalid response from the coverage service. Please check the service status."}]
            })
            
            result = await agent.run_with_monitoring("Check coverage")
            
            assert "invalid response" in result["response"].lower()
    
    @pytest.mark.asyncio
    async def test_network_connectivity_issues(self, agent):
        """Test handling of network connectivity problems."""
        
        with patch('httpx.AsyncClient') as mock_client:
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                side_effect=httpx.ConnectError("Network unreachable")
            )
            
            agent.agent_executor.ainvoke = AsyncMock(return_value={
                "messages": [{"content": "I'm unable to connect to the coverage analysis service. Please check your network connection."}]
            })
            
            result = await agent.run_with_monitoring("Analyze coverage")
            
            assert "network" in result["response"].lower() or "connect" in result["response"].lower()
```

## 📊 Step 5: Testing Automation Setup

Create automated testing workflows:

```yaml
# .github/workflows/test-agent.yml (for GitHub) or adapt for GitLab
name: Agent Testing Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    strategy:
      matrix:
        python-version: [3.9, 3.10, 3.11]
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v3
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install Poetry
      uses: snok/install-poetry@v1
    
    - name: Install dependencies
      run: poetry install
    
    - name: Run unit tests
      run: |
        poetry run pytest tests/unit/ -v --cov=src --cov-report=xml
    
    - name: Run integration tests
      run: |
        poetry run pytest tests/integration/ -v
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
    
    - name: Run performance tests
      run: |
        poetry run pytest tests/performance/ -v --benchmark-only
    
    - name: Upload coverage reports
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml
```

## 🔧 Step 6: Manual Testing Procedures

Create manual testing checklists:

```markdown
# Manual Testing Checklist

## Basic Functionality
- [ ] Agent starts successfully
- [ ] Simple queries receive appropriate responses
- [ ] Help command works correctly
- [ ] Exit commands function properly

## Tool Integration
- [ ] CheckCoverage tool executes successfully
- [ ] GetCopy tool retrieves content correctly
- [ ] Tool errors are handled gracefully
- [ ] Tool results are properly formatted

## Conversation Flow
- [ ] Multi-turn conversations maintain context
- [ ] Agent remembers previous tool calls
- [ ] Conversation history is accurate
- [ ] Reset function clears state properly

## Performance
- [ ] Response times are under 5 seconds
- [ ] Concurrent users don't cause errors
- [ ] Memory usage remains stable
- [ ] No obvious memory leaks

## Error Handling
- [ ] Invalid inputs are handled safely
- [ ] API failures don't crash the agent
- [ ] Network issues are reported clearly
- [ ] Recovery mechanisms work correctly

## Security
- [ ] Input sanitization prevents injection
- [ ] API keys are not exposed in logs
- [ ] Error messages don't leak sensitive data
- [ ] Rate limiting is respected
```

## 📈 Step 7: Performance Monitoring Setup

Create monitoring and alerting:

```python
# scripts/monitor_agent.py
#!/usr/bin/env python3
"""
Agent monitoring script for production environments.
"""

import asyncio
import time
import json
from datetime import datetime, timedelta
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from react_agent.agent import ReactAgentWithMonitoring

class AgentMonitor:
    """Production monitoring for the ReAct agent."""
    
    def __init__(self):
        self.agent = ReactAgentWithMonitoring()
        self.metrics = {
            "uptime_start": datetime.utcnow(),
            "health_checks": 0,
            "failed_health_checks": 0,
            "alerts_sent": 0
        }
    
    async def health_check(self) -> bool:
        """Perform a health check on the agent."""
        try:
            result = await self.agent.run_with_monitoring("Health check test")
            self.metrics["health_checks"] += 1
            return result["status"] == "success"
        except Exception as e:
            self.metrics["failed_health_checks"] += 1
            print(f"Health check failed: {e}")
            return False
    
    async def monitor_loop(self, interval_seconds: int = 60):
        """Continuous monitoring loop."""
        print(f"Starting agent monitoring (interval: {interval_seconds}s)")
        
        while True:
            try:
                # Perform health check
                is_healthy = await self.health_check()
                
                # Get performance metrics
                report = self.agent.get_performance_report()
                
                # Log status
                status = {
                    "timestamp": datetime.utcnow().isoformat(),
                    "healthy": is_healthy,
                    "uptime_hours": (datetime.utcnow() - self.metrics["uptime_start"]).total_seconds() / 3600,
                    "performance": report["summary"],
                    "health_check_success_rate": (
                        (self.metrics["health_checks"] - self.metrics["failed_health_checks"]) / 
                        max(self.metrics["health_checks"], 1) * 100
                    )
                }
                
                print(json.dumps(status, indent=2))
                
                # Alert on failures
                if not is_healthy:
                    await self.send_alert("Agent health check failed")
                
                await asyncio.sleep(interval_seconds)
                
            except KeyboardInterrupt:
                print("\nMonitoring stopped by user")
                break
            except Exception as e:
                print(f"Monitoring error: {e}")
                await asyncio.sleep(interval_seconds)
    
    async def send_alert(self, message: str):
        """Send alert (implement your alerting mechanism)."""
        self.metrics["alerts_sent"] += 1
        print(f"ALERT: {message}")
        # Implement email, Slack, or other alerting here

async def main():
    monitor = AgentMonitor()
    await monitor.monitor_loop()

if __name__ == "__main__":
    asyncio.run(main())
```

## ✅ Integration & Testing Complete

You've now implemented:

- ✅ Comprehensive integration testing suite
- ✅ Performance validation and benchmarking
- ✅ Real API integration testing capabilities
- ✅ Error scenario validation
- ✅ Automated testing pipelines
- ✅ Manual testing procedures
- ✅ Production monitoring setup

Your Foundation ReAct Agent is now thoroughly tested and ready for production deployment. Proceed to [Production Deployment](production-deployment.md) for the final deployment steps.