# Agent Implementation

This section guides you through implementing the ReAct agent using LangGraph's create-react-agent functionality. We'll integrate the CheckCoverage and GetCopy tools and build a sophisticated reasoning and acting system.

## 🎯 Learning Objectives

By the end of this section, you will:
- Implement a ReAct agent using LangGraph's create-react-agent
- Configure the agent with custom tools and prompting
- Handle state management and conversation flow
- Implement error recovery and tool fallback mechanisms
- Add structured logging and monitoring
- Create a production-ready agent interface

## 🧠 ReAct Agent Architecture

Our agent follows the ReAct pattern with these components:

```mermaid
graph TD
    A[User Input] --> B[Agent State]
    B --> C[LLM Reasoning]
    C --> D{Action Needed?}
    D -->|Yes| E[Tool Selection]
    D -->|No| F[Final Response]
    E --> G[Tool Execution]
    G --> H[Observation Processing]
    H --> I[State Update]
    I --> C
    F --> J[User Output]
```

## 📝 Step 1: Agent Implementation

Create the main ReAct agent implementation:

```python
# src/react_agent/agent.py
from typing import Dict, List, Any, Optional, AsyncGenerator
from langgraph import StateGraph, END
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, SystemMessage
from langchain.tools import BaseTool
import logging
import asyncio
from datetime import datetime

from .tools import tool_registry
from .config.settings import settings
from .utils.helpers import setup_logging, sanitize_input

logger = logging.getLogger(__name__)

class ReactAgentState:
    """State management for the ReAct agent."""
    
    def __init__(self):
        self.messages: List[Dict[str, Any]] = []
        self.tool_calls: List[Dict[str, Any]] = []
        self.iteration_count: int = 0
        self.last_action: Optional[str] = None
        self.context: Dict[str, Any] = {}
        self.session_id: str = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    def add_message(self, role: str, content: str, metadata: Optional[Dict] = None):
        """Add a message to the conversation history."""
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.utcnow().isoformat(),
            "metadata": metadata or {}
        }
        self.messages.append(message)
        logger.debug(f"Added {role} message: {content[:100]}...")
    
    def add_tool_call(self, tool_name: str, inputs: Dict, outputs: str, success: bool):
        """Record a tool call for debugging and analysis."""
        tool_call = {
            "tool_name": tool_name,
            "inputs": inputs,
            "outputs": outputs,
            "success": success,
            "timestamp": datetime.utcnow().isoformat(),
            "iteration": self.iteration_count
        }
        self.tool_calls.append(tool_call)
        logger.info(f"Tool call recorded: {tool_name} - Success: {success}")
    
    def get_conversation_history(self, limit: int = 10) -> List[Dict]:
        """Get recent conversation history."""
        return self.messages[-limit:] if self.messages else []

class ReactAgent:
    """Foundation ReAct Agent with LangGraph integration."""
    
    def __init__(self):
        self.llm = self._initialize_llm()
        self.tools = self._get_available_tools()
        self.agent_executor = self._create_agent()
        self.state = ReactAgentState()
        
        # Setup logging
        self.logger = setup_logging(
            level=settings.log_level,
            format_type=settings.log_format,
            log_file=settings.log_file
        )
        
        self.logger.info("ReactAgent initialized successfully")
    
    def _initialize_llm(self) -> ChatOpenAI:
        """Initialize the language model."""
        return ChatOpenAI(
            model=settings.openai_model,
            temperature=settings.openai_temperature,
            openai_api_key=settings.openai_api_key,
            streaming=True
        )
    
    def _get_available_tools(self) -> List[BaseTool]:
        """Get all available tools from the registry."""
        tools = tool_registry.get_all_tools()
        self.logger.info(f"Loaded {len(tools)} tools: {[tool.name for tool in tools]}")
        return tools
    
    def _create_agent(self):
        """Create the ReAct agent using LangGraph."""
        
        # Define the system prompt for the ReAct agent
        system_prompt = self._get_system_prompt()
        
        # Create the agent with tools
        agent = create_react_agent(
            model=self.llm,
            tools=self.tools,
            state_modifier=system_prompt
        )
        
        return agent
    
    def _get_system_prompt(self) -> str:
        """Get the system prompt for the ReAct agent."""
        tool_descriptions = "\n".join([
            f"- {tool.name}: {tool.description}" 
            for tool in self.tools
        ])
        
        return f"""You are a helpful AI assistant with access to specialized tools for enterprise tasks.

AVAILABLE TOOLS:
{tool_descriptions}

INSTRUCTIONS:
1. Always think step by step about what the user is asking
2. Use tools when they can provide better information than your knowledge
3. If a tool fails, try to understand why and suggest alternatives
4. Provide clear, actionable responses based on tool results
5. Be concise but thorough in your explanations

RESPONSE FORMAT:
- Start with a brief summary of what you'll do
- Use tools as needed to gather information
- Synthesize results into a clear, actionable response
- Include relevant details from tool outputs

Remember: You're designed to help with code coverage analysis and content management tasks using the available tools."""
    
    async def run(self, user_input: str) -> str:
        """Run the agent with user input."""
        try:
            # Sanitize and validate input
            clean_input = sanitize_input(user_input)
            if not clean_input.strip():
                return "Please provide a valid input."
            
            self.logger.info(f"Processing user input: {clean_input[:100]}...")
            self.state.add_message("user", clean_input)
            
            # Reset iteration counter
            self.state.iteration_count = 0
            
            # Prepare the input for the agent
            messages = [HumanMessage(content=clean_input)]
            
            # Run the agent
            response = await self._execute_agent(messages)
            
            # Record the response
            self.state.add_message("assistant", response)
            
            return response
            
        except Exception as e:
            error_msg = f"Error processing request: {str(e)}"
            self.logger.error(error_msg)
            return f"I encountered an error while processing your request: {str(e)}"
    
    async def _execute_agent(self, messages: List) -> str:
        """Execute the agent with proper error handling."""
        try:
            # Create the input state
            input_state = {"messages": messages}
            
            # Run the agent
            result = await self.agent_executor.ainvoke(input_state)
            
            # Extract the response
            if "messages" in result and result["messages"]:
                last_message = result["messages"][-1]
                if hasattr(last_message, 'content'):
                    return last_message.content
                elif isinstance(last_message, dict) and 'content' in last_message:
                    return last_message['content']
            
            return "I apologize, but I wasn't able to generate a proper response."
            
        except Exception as e:
            self.logger.error(f"Agent execution failed: {e}")
            return f"I encountered an error: {str(e)}"
    
    async def stream_response(self, user_input: str) -> AsyncGenerator[str, None]:
        """Stream the agent response for real-time interaction."""
        try:
            clean_input = sanitize_input(user_input)
            self.state.add_message("user", clean_input)
            
            messages = [HumanMessage(content=clean_input)]
            input_state = {"messages": messages}
            
            # Stream the response
            async for chunk in self.agent_executor.astream(input_state):
                if "messages" in chunk and chunk["messages"]:
                    last_message = chunk["messages"][-1]
                    if hasattr(last_message, 'content') and last_message.content:
                        yield last_message.content
            
        except Exception as e:
            self.logger.error(f"Streaming failed: {e}")
            yield f"Error: {str(e)}"
    
    def get_conversation_history(self) -> List[Dict]:
        """Get the current conversation history."""
        return self.state.get_conversation_history()
    
    def get_tool_usage_stats(self) -> Dict[str, Any]:
        """Get statistics about tool usage."""
        if not self.state.tool_calls:
            return {"total_calls": 0, "tools_used": [], "success_rate": 0}
        
        total_calls = len(self.state.tool_calls)
        successful_calls = sum(1 for call in self.state.tool_calls if call["success"])
        tools_used = list(set(call["tool_name"] for call in self.state.tool_calls))
        
        return {
            "total_calls": total_calls,
            "successful_calls": successful_calls,
            "success_rate": (successful_calls / total_calls) * 100,
            "tools_used": tools_used,
            "recent_calls": self.state.tool_calls[-5:]  # Last 5 calls
        }
    
    def reset_conversation(self):
        """Reset the conversation state."""
        self.state = ReactAgentState()
        self.logger.info("Conversation state reset")
    
    def export_session_data(self) -> Dict[str, Any]:
        """Export session data for analysis or debugging."""
        return {
            "session_id": self.state.session_id,
            "messages": self.state.messages,
            "tool_calls": self.state.tool_calls,
            "conversation_length": len(self.state.messages),
            "tools_used": list(set(call["tool_name"] for call in self.state.tool_calls)),
            "session_duration": datetime.utcnow().isoformat()
        }
```

## 🔧 Step 2: Enhanced Agent Features

Add advanced features for enterprise use:

```python
# src/react_agent/agent.py (continued)

class ReactAgentWithMonitoring(ReactAgent):
    """Enhanced ReactAgent with monitoring and analytics."""
    
    def __init__(self):
        super().__init__()
        self.performance_metrics = {
            "total_requests": 0,
            "successful_requests": 0,
            "average_response_time": 0,
            "tool_usage_frequency": {},
            "error_counts": {}
        }
    
    async def run_with_monitoring(self, user_input: str) -> Dict[str, Any]:
        """Run the agent with performance monitoring."""
        start_time = datetime.utcnow()
        
        try:
            self.performance_metrics["total_requests"] += 1
            
            # Run the agent
            response = await self.run(user_input)
            
            # Calculate response time
            end_time = datetime.utcnow()
            response_time = (end_time - start_time).total_seconds()
            
            # Update metrics
            self.performance_metrics["successful_requests"] += 1
            self._update_response_time_metric(response_time)
            
            return {
                "response": response,
                "response_time": response_time,
                "status": "success",
                "tool_calls": len(self.state.tool_calls),
                "session_id": self.state.session_id
            }
            
        except Exception as e:
            # Track errors
            error_type = type(e).__name__
            self.performance_metrics["error_counts"][error_type] = \
                self.performance_metrics["error_counts"].get(error_type, 0) + 1
            
            self.logger.error(f"Monitored execution failed: {e}")
            
            return {
                "response": f"Error: {str(e)}",
                "response_time": (datetime.utcnow() - start_time).total_seconds(),
                "status": "error",
                "error_type": error_type,
                "session_id": self.state.session_id
            }
    
    def _update_response_time_metric(self, response_time: float):
        """Update the average response time metric."""
        current_avg = self.performance_metrics["average_response_time"]
        successful_requests = self.performance_metrics["successful_requests"]
        
        # Calculate new average
        if successful_requests == 1:
            self.performance_metrics["average_response_time"] = response_time
        else:
            new_avg = ((current_avg * (successful_requests - 1)) + response_time) / successful_requests
            self.performance_metrics["average_response_time"] = new_avg
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Generate a performance report."""
        success_rate = 0
        if self.performance_metrics["total_requests"] > 0:
            success_rate = (
                self.performance_metrics["successful_requests"] / 
                self.performance_metrics["total_requests"]
            ) * 100
        
        return {
            "summary": {
                "total_requests": self.performance_metrics["total_requests"],
                "successful_requests": self.performance_metrics["successful_requests"],
                "success_rate": round(success_rate, 2),
                "average_response_time": round(self.performance_metrics["average_response_time"], 3)
            },
            "tool_usage": self.get_tool_usage_stats(),
            "errors": self.performance_metrics["error_counts"],
            "current_session": self.state.session_id
        }
```

## 🧪 Step 3: Integration Testing

Create integration tests for the complete agent:

```python
# tests/integration/test_agent_integration.py
import pytest
from unittest.mock import AsyncMock, Mock, patch
from src.react_agent.agent import ReactAgent, ReactAgentWithMonitoring

class TestReactAgentIntegration:
    """Integration tests for the ReactAgent."""
    
    @pytest.fixture
    def agent(self):
        with patch('src.react_agent.agent.ChatOpenAI') as mock_llm:
            mock_llm.return_value = Mock()
            agent = ReactAgent()
            return agent
    
    @pytest.fixture
    def monitoring_agent(self):
        with patch('src.react_agent.agent.ChatOpenAI') as mock_llm:
            mock_llm.return_value = Mock()
            agent = ReactAgentWithMonitoring()
            return agent
    
    @pytest.mark.asyncio
    async def test_agent_basic_interaction(self, agent):
        """Test basic agent interaction."""
        
        with patch.object(agent, '_execute_agent') as mock_execute:
            mock_execute.return_value = "Hello! I'm ready to help with your tasks."
            
            response = await agent.run("Hello, can you help me?")
            
            assert response == "Hello! I'm ready to help with your tasks."
            assert len(agent.state.messages) == 2  # User + Assistant
            assert agent.state.messages[0]["role"] == "user"
            assert agent.state.messages[1]["role"] == "assistant"
    
    @pytest.mark.asyncio
    async def test_agent_with_tool_usage(self, agent):
        """Test agent interaction with tool usage."""
        
        # Mock a response that indicates tool usage
        mock_response = """I'll check the code coverage for your project.

        Let me analyze the coverage using the CheckCoverage tool.

        Based on the coverage analysis, your project has 85.5% total coverage, which meets the 80% threshold."""
        
        with patch.object(agent, '_execute_agent') as mock_execute:
            mock_execute.return_value = mock_response
            
            response = await agent.run("Check coverage for my Python project at /path/to/project")
            
            assert "coverage" in response.lower()
            assert "85.5%" in response
    
    @pytest.mark.asyncio
    async def test_agent_error_handling(self, agent):
        """Test agent error handling."""
        
        with patch.object(agent, '_execute_agent') as mock_execute:
            mock_execute.side_effect = Exception("LLM service unavailable")
            
            response = await agent.run("Test error handling")
            
            assert "error" in response.lower()
            assert "LLM service unavailable" in response
    
    @pytest.mark.asyncio
    async def test_monitoring_agent_metrics(self, monitoring_agent):
        """Test monitoring agent performance tracking."""
        
        with patch.object(monitoring_agent, '_execute_agent') as mock_execute:
            mock_execute.return_value = "Test response"
            
            # Run multiple requests
            for i in range(3):
                result = await monitoring_agent.run_with_monitoring(f"Test request {i}")
                assert result["status"] == "success"
                assert "response_time" in result
            
            # Check performance metrics
            report = monitoring_agent.get_performance_report()
            assert report["summary"]["total_requests"] == 3
            assert report["summary"]["successful_requests"] == 3
            assert report["summary"]["success_rate"] == 100.0
    
    @pytest.mark.asyncio
    async def test_conversation_history(self, agent):
        """Test conversation history tracking."""
        
        with patch.object(agent, '_execute_agent') as mock_execute:
            mock_execute.return_value = "Test response"
            
            # Multiple interactions
            await agent.run("First message")
            await agent.run("Second message")
            await agent.run("Third message")
            
            history = agent.get_conversation_history()
            assert len(history) == 6  # 3 user + 3 assistant messages
            
            # Check message ordering
            assert history[0]["role"] == "user"
            assert history[1]["role"] == "assistant"
            assert history[2]["role"] == "user"
    
    @pytest.mark.asyncio
    async def test_session_data_export(self, agent):
        """Test session data export functionality."""
        
        with patch.object(agent, '_execute_agent') as mock_execute:
            mock_execute.return_value = "Test response"
            
            await agent.run("Test message")
            
            session_data = agent.export_session_data()
            
            assert "session_id" in session_data
            assert "messages" in session_data
            assert "tool_calls" in session_data
            assert session_data["conversation_length"] == 2
    
    def test_agent_reset(self, agent):
        """Test agent conversation reset."""
        
        # Add some state
        agent.state.add_message("user", "Test message")
        agent.state.add_tool_call("test_tool", {}, "result", True)
        
        assert len(agent.state.messages) == 1
        assert len(agent.state.tool_calls) == 1
        
        # Reset and verify
        agent.reset_conversation()
        
        assert len(agent.state.messages) == 0
        assert len(agent.state.tool_calls) == 0
```

## 🚀 Step 4: Enhanced Runner Script

Update the runner script with the new agent features:

```python
# scripts/run_agent.py (enhanced version)
#!/usr/bin/env python3
"""
Enhanced script to run the ReAct agent with monitoring and advanced features.
"""

import asyncio
import sys
import json
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from react_agent.agent import ReactAgentWithMonitoring
from react_agent.config.settings import settings
from react_agent.utils.helpers import setup_logging

console = Console()

class AgentInterface:
    """Interactive interface for the ReAct agent."""
    
    def __init__(self):
        self.agent = ReactAgentWithMonitoring()
        self.logger = setup_logging(
            level=settings.log_level,
            format_type=settings.log_format,
            log_file=settings.log_file
        )
    
    async def run(self):
        """Run the interactive agent interface."""
        console.print(Panel("🤖 Foundation ReAct Agent", style="bold blue"))
        console.print("Type 'help' for commands, 'quit' to exit\n")
        
        while True:
            try:
                user_input = console.input("[bold green]> [/bold green]").strip()
                
                if user_input.lower() in ['quit', 'exit', 'q']:
                    break
                elif user_input.lower() == 'help':
                    self.show_help()
                    continue
                elif user_input.lower() == 'stats':
                    self.show_performance_stats()
                    continue
                elif user_input.lower() == 'history':
                    self.show_conversation_history()
                    continue
                elif user_input.lower() == 'reset':
                    self.agent.reset_conversation()
                    console.print("✅ Conversation reset", style="green")
                    continue
                elif not user_input:
                    continue
                
                # Process the request
                with console.status("[bold yellow]Thinking...", spinner="dots"):
                    result = await self.agent.run_with_monitoring(user_input)
                
                # Display response
                self.display_response(result)
                
            except KeyboardInterrupt:
                console.print("\n👋 Goodbye!", style="bold yellow")
                break
            except Exception as e:
                console.print(f"❌ Error: {e}", style="bold red")
    
    def display_response(self, result: dict):
        """Display the agent response with formatting."""
        status_color = "green" if result["status"] == "success" else "red"
        
        # Response panel
        console.print(Panel(
            result["response"],
            title="🤖 Agent Response",
            border_style=status_color
        ))
        
        # Metadata
        metadata = f"Time: {result['response_time']:.2f}s | Status: {result['status']}"
        if "tool_calls" in result:
            metadata += f" | Tools: {result['tool_calls']}"
        
        console.print(f"[dim]{metadata}[/dim]\n")
    
    def show_help(self):
        """Show available commands."""
        help_table = Table(title="Available Commands")
        help_table.add_column("Command", style="cyan")
        help_table.add_column("Description", style="white")
        
        help_table.add_row("help", "Show this help message")
        help_table.add_row("stats", "Show performance statistics")
        help_table.add_row("history", "Show conversation history")
        help_table.add_row("reset", "Reset conversation")
        help_table.add_row("quit/exit/q", "Exit the agent")
        help_table.add_row("[text]", "Send message to agent")
        
        console.print(help_table)
        console.print()
    
    def show_performance_stats(self):
        """Show performance statistics."""
        report = self.agent.get_performance_report()
        
        stats_table = Table(title="Performance Statistics")
        stats_table.add_column("Metric", style="cyan")
        stats_table.add_column("Value", style="white")
        
        summary = report["summary"]
        stats_table.add_row("Total Requests", str(summary["total_requests"]))
        stats_table.add_row("Successful Requests", str(summary["successful_requests"]))
        stats_table.add_row("Success Rate", f"{summary['success_rate']}%")
        stats_table.add_row("Avg Response Time", f"{summary['average_response_time']}s")
        
        console.print(stats_table)
        console.print()
    
    def show_conversation_history(self):
        """Show recent conversation history."""
        history = self.agent.get_conversation_history()
        
        if not history:
            console.print("No conversation history available.", style="yellow")
            return
        
        console.print(Panel("Recent Conversation History", style="blue"))
        
        for msg in history[-10:]:  # Show last 10 messages
            role_style = "green" if msg["role"] == "user" else "blue"
            role_icon = "👤" if msg["role"] == "user" else "🤖"
            
            console.print(f"{role_icon} [{role_style}]{msg['role'].title()}[/{role_style}]: {msg['content'][:100]}...")
            console.print()

async def main():
    """Main entry point."""
    interface = AgentInterface()
    await interface.run()

if __name__ == "__main__":
    asyncio.run(main())
```

## ✅ Agent Implementation Complete

You've now implemented:

- ✅ Complete ReAct agent using LangGraph's create-react-agent
- ✅ Integration with CheckCoverage and GetCopy tools
- ✅ State management and conversation tracking
- ✅ Performance monitoring and analytics
- ✅ Error handling and recovery mechanisms
- ✅ Interactive interface with rich formatting
- ✅ Comprehensive integration testing

## 🔄 Next Steps

Your agent is ready for integration testing! Proceed to [Integration & Testing](integration-testing.md) to validate the complete system and prepare for production deployment.