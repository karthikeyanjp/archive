# Project Setup

This guide walks you through creating a complete development environment for your Foundation ReAct Agent. We'll use Poetry for dependency management and establish a professional project structure suitable for enterprise development.

## 🎯 Learning Objectives

By the end of this setup, you will have:
- A properly configured Poetry project with all dependencies
- A structured codebase following Python best practices
- Environment configuration for development and production
- Testing framework setup with sample tests
- Development scripts for running and testing the agent

## 📁 Step 1: Create Project Directory

First, create your project directory and navigate into it:

```bash
# Create the main project directory
mkdir react-agent-foundation
cd react-agent-foundation

# Initialize git repository
git init
```

## 🏗️ Step 2: Initialize Poetry Project

Poetry will manage our dependencies and virtual environment:

```bash
# Initialize Poetry project with interactive prompts
poetry init

# Or use this non-interactive version with pre-filled values:
poetry init \
  --name "react-agent-foundation" \
  --version "0.1.0" \
  --description "Foundation ReAct Agent with LangGraph and Enterprise Tools" \
  --author "Your Name <your.email@company.com>" \
  --python "^3.9" \
  --no-interaction
```

## 📦 Step 3: Install Core Dependencies

Add the essential dependencies for our ReAct agent:

```bash
# Core LangGraph and LangChain dependencies
poetry add langgraph langchain langchain-openai

# Additional utilities
poetry add python-dotenv pydantic httpx aiohttp

# Development dependencies
poetry add --group dev pytest pytest-asyncio pytest-mock black isort mypy

# Testing and debugging
poetry add --group dev pytest-cov ipdb rich

# Documentation (optional)
poetry add --group dev mkdocs mkdocs-material
```

Your `pyproject.toml` should look similar to this:

```toml
[tool.poetry]
name = "react-agent-foundation"
version = "0.1.0"
description = "Foundation ReAct Agent with LangGraph and Enterprise Tools"
authors = ["Your Name <your.email@company.com>"]
readme = "README.md"
packages = [{include = "react_agent", from = "src"}]

[tool.poetry.dependencies]
python = "^3.9"
langgraph = "^0.0.40"
langchain = "^0.1.0"
langchain-openai = "^0.0.8"
python-dotenv = "^1.0.0"
pydantic = "^2.0.0"
httpx = "^0.25.0"
aiohttp = "^3.9.0"

[tool.poetry.group.dev.dependencies]
pytest = "^7.4.0"
pytest-asyncio = "^0.21.0"
pytest-mock = "^3.11.0"
pytest-cov = "^4.1.0"
black = "^23.0.0"
isort = "^5.12.0"
mypy = "^1.5.0"
ipdb = "^0.13.0"
rich = "^13.5.0"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"

[tool.black]
line-length = 88
target-version = ['py39']
include = '\.pyi?$'

[tool.isort]
profile = "black"
multi_line_output = 3

[tool.mypy]
python_version = "3.9"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
```

## 📂 Step 4: Create Project Structure

Create the complete directory structure:

```bash
# Create source directories
mkdir -p src/react_agent/{tools,config,utils}

# Create test directories
mkdir -p tests/{unit,integration,fixtures}

# Create scripts directory
mkdir scripts

# Create docs directory (if using documentation)
mkdir docs

# Create logs directory
mkdir logs
```

Now create the essential files:

```bash
# Create __init__.py files
touch src/__init__.py
touch src/react_agent/__init__.py
touch src/react_agent/tools/__init__.py
touch src/react_agent/config/__init__.py
touch src/react_agent/utils/__init__.py
touch tests/__init__.py
touch tests/unit/__init__.py
touch tests/integration/__init__.py
touch tests/fixtures/__init__.py
```

## ⚙️ Step 5: Environment Configuration

Create environment configuration files:

### .env.example
```bash
# Create environment template
cat > .env.example << 'EOF'
# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_MODEL=gpt-4
OPENAI_TEMPERATURE=0.1

# Agent Configuration
AGENT_NAME=react-foundation-agent
AGENT_VERSION=1.0.0
MAX_ITERATIONS=10
TIMEOUT_SECONDS=30

# Tool Configuration
CHECKCOVERAGE_API_URL=https://api.coverage-service.com
CHECKCOVERAGE_API_KEY=your_coverage_api_key
GETCOPY_API_URL=https://api.content-service.com
GETCOPY_API_KEY=your_copy_api_key

# Logging Configuration
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE=logs/agent.log

# Development Configuration
DEBUG=False
TESTING=False
EOF
```

### .env (for development)
```bash
# Copy the example and add your actual values
cp .env.example .env

# Edit .env with your actual API keys
# Note: Never commit .env to version control
```

## 📝 Step 6: Configuration Management

Create the settings configuration:

```python
# src/react_agent/config/settings.py
from typing import Optional
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    """Application settings with environment variable support."""
    
    # OpenAI Configuration
    openai_api_key: str = Field(..., env="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4", env="OPENAI_MODEL")
    openai_temperature: float = Field(default=0.1, env="OPENAI_TEMPERATURE")
    
    # Agent Configuration
    agent_name: str = Field(default="react-foundation-agent", env="AGENT_NAME")
    agent_version: str = Field(default="1.0.0", env="AGENT_VERSION")
    max_iterations: int = Field(default=10, env="MAX_ITERATIONS")
    timeout_seconds: int = Field(default=30, env="TIMEOUT_SECONDS")
    
    # Tool Configuration
    checkcoverage_api_url: str = Field(..., env="CHECKCOVERAGE_API_URL")
    checkcoverage_api_key: str = Field(..., env="CHECKCOVERAGE_API_KEY")
    getcopy_api_url: str = Field(..., env="GETCOPY_API_URL")
    getcopy_api_key: str = Field(..., env="GETCOPY_API_KEY")
    
    # Logging Configuration
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_format: str = Field(default="json", env="LOG_FORMAT")
    log_file: str = Field(default="logs/agent.log", env="LOG_FILE")
    
    # Development Configuration
    debug: bool = Field(default=False, env="DEBUG")
    testing: bool = Field(default=False, env="TESTING")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

# Global settings instance
settings = Settings()
```

## 🛠️ Step 7: Utility Functions

Create essential utility functions:

```python
# src/react_agent/utils/helpers.py
import logging
import json
from typing import Any, Dict, Optional
from datetime import datetime
from pathlib import Path

def setup_logging(
    level: str = "INFO",
    format_type: str = "json",
    log_file: Optional[str] = None
) -> logging.Logger:
    """Set up structured logging for the agent."""
    
    logger = logging.getLogger("react_agent")
    logger.setLevel(getattr(logging, level.upper()))
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler()
    
    if format_type == "json":
        formatter = JsonFormatter()
    else:
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler (if specified)
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

class JsonFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields
        for key, value in record.__dict__.items():
            if key not in log_entry and not key.startswith("_"):
                log_entry[key] = value
        
        return json.dumps(log_entry)

def validate_api_response(response: Dict[str, Any]) -> bool:
    """Validate API response structure."""
    required_fields = ["status", "data"]
    return all(field in response for field in required_fields)

def sanitize_input(input_text: str) -> str:
    """Sanitize user input for security."""
    # Remove potentially harmful characters
    forbidden_chars = ["<", ">", "&", "'", '"']
    sanitized = input_text
    for char in forbidden_chars:
        sanitized = sanitized.replace(char, "")
    return sanitized.strip()
```

## 🧪 Step 8: Basic Test Setup

Create initial test files:

```python
# tests/conftest.py
import pytest
import asyncio
from typing import Generator
from unittest.mock import Mock, AsyncMock

@pytest.fixture(scope="session")
def event_loop() -> Generator:
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture
def mock_openai_client():
    """Mock OpenAI client for testing."""
    mock_client = Mock()
    mock_client.chat = Mock()
    mock_client.chat.completions = Mock()
    mock_client.chat.completions.create = AsyncMock()
    return mock_client

@pytest.fixture
def sample_coverage_data():
    """Sample coverage data for testing."""
    return {
        "project_path": "/path/to/project",
        "total_coverage": 85.5,
        "line_coverage": 87.2,
        "branch_coverage": 83.8,
        "uncovered_lines": [
            {"file": "src/module.py", "lines": [42, 43, 56]},
            {"file": "src/utils.py", "lines": [12, 28]}
        ]
    }

@pytest.fixture
def sample_copy_data():
    """Sample copy data for testing."""
    return {
        "content_id": "PROMO_001",
        "template_type": "email_campaign",
        "target_audience": "enterprise_customers",
        "content": {
            "subject": "Unlock Enterprise AI Solutions",
            "body": "Transform your business with our AI platform...",
            "cta": "Schedule Demo"
        },
        "metadata": {
            "created_at": "2024-01-15T10:30:00Z",
            "approved": True,
            "version": "1.2"
        }
    }
```

## 📋 Step 9: Development Scripts

Create scripts for running and testing:

```python
# scripts/run_agent.py
#!/usr/bin/env python3
"""
Script to run the ReAct agent interactively.
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from react_agent.agent import ReactAgent
from react_agent.config.settings import settings
from react_agent.utils.helpers import setup_logging

async def main():
    """Run the agent interactively."""
    
    # Setup logging
    logger = setup_logging(
        level=settings.log_level,
        format_type=settings.log_format,
        log_file=settings.log_file
    )
    
    logger.info("Starting ReAct Agent")
    
    try:
        # Initialize agent (will be implemented in next section)
        agent = ReactAgent()
        
        print("🤖 ReAct Agent Ready!")
        print("Type 'quit' to exit, 'help' for commands")
        
        while True:
            user_input = input("\n> ").strip()
            
            if user_input.lower() in ['quit', 'exit', 'q']:
                break
            elif user_input.lower() == 'help':
                print("Available commands:")
                print("  quit/exit/q - Exit the agent")
                print("  help - Show this help message")
                print("  [any text] - Send message to agent")
                continue
            elif not user_input:
                continue
            
            try:
                response = await agent.run(user_input)
                print(f"\n🤖: {response}")
            except Exception as e:
                logger.error(f"Error processing request: {e}")
                print(f"❌ Error: {e}")
    
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        print(f"❌ Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
```

```bash
# scripts/test_tools.py
#!/usr/bin/env python3
"""
Script to test individual tools.
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from react_agent.tools.check_coverage import CheckCoverageTool
from react_agent.tools.get_copy import GetCopyTool
from react_agent.utils.helpers import setup_logging

async def test_check_coverage():
    """Test the CheckCoverage tool."""
    print("🧪 Testing CheckCoverage Tool...")
    
    tool = CheckCoverageTool()
    
    test_input = {
        "project_path": "/example/project",
        "test_config": "pytest"
    }
    
    try:
        result = await tool.run(test_input)
        print(f"✅ CheckCoverage Result: {result}")
    except Exception as e:
        print(f"❌ CheckCoverage Error: {e}")

async def test_get_copy():
    """Test the GetCopy tool."""
    print("🧪 Testing GetCopy Tool...")
    
    tool = GetCopyTool()
    
    test_input = {
        "content_id": "PROMO_001",
        "template_type": "email_campaign",
        "target_audience": "enterprise_customers"
    }
    
    try:
        result = await tool.run(test_input)
        print(f"✅ GetCopy Result: {result}")
    except Exception as e:
        print(f"❌ GetCopy Error: {e}")

async def main():
    """Run all tool tests."""
    setup_logging(level="INFO")
    
    print("🚀 Starting Tool Tests...\n")
    
    await test_check_coverage()
    print()
    await test_get_copy()
    
    print("\n✅ Tool tests completed!")

if __name__ == "__main__":
    asyncio.run(main())
```

## 📄 Step 10: Documentation Files

Create essential documentation:

```markdown
# README.md
# Foundation ReAct Agent

Enterprise-grade ReAct agent built with LangGraph and integrated with CheckCoverage and GetCopy tools.

## Quick Start

1. Install Poetry: `pip install poetry`
2. Install dependencies: `poetry install`
3. Copy environment: `cp .env.example .env`
4. Add your API keys to `.env`
5. Run the agent: `poetry run python scripts/run_agent.py`

## Development

- Run tests: `poetry run pytest`
- Format code: `poetry run black src tests`
- Type checking: `poetry run mypy src`
- Test tools: `poetry run python scripts/test_tools.py`

## Project Structure

- `src/react_agent/` - Main agent code
- `tests/` - Test suite
- `scripts/` - Development scripts
- `docs/` - Documentation

## Tools

- **CheckCoverage**: Analyzes code coverage metrics
- **GetCopy**: Retrieves marketing copy and content

For detailed documentation, see the `docs/` directory.
```

```gitignore
# .gitignore
# Environment variables
.env
.env.local

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# Poetry
poetry.lock

# Testing
.coverage
.pytest_cache/
htmlcov/
.tox/

# Logging
logs/
*.log

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db
```

## 🎯 Step 11: Verify Installation

Install the project and verify everything works:

```bash
# Install all dependencies
poetry install

# Verify installation
poetry run python -c "import react_agent; print('✅ Installation successful!')"

# Run basic tests (after we create tools in next section)
poetry run pytest tests/ -v

# Check code formatting
poetry run black --check src tests

# Type checking
poetry run mypy src
```

## ✅ Setup Complete!

Your Foundation ReAct Agent project is now properly set up with:

- ✅ Poetry-managed dependencies
- ✅ Professional project structure
- ✅ Environment configuration
- ✅ Logging and utilities
- ✅ Testing framework
- ✅ Development scripts
- ✅ Documentation templates

## 🔄 Next Steps

1. Review your `.env` file and add the required API keys
2. Proceed to [Tool Development](tool-development.md) to build the CheckCoverage and GetCopy tools
3. Test the setup by running `poetry run python scripts/test_tools.py`

The foundation is ready - let's build some tools!