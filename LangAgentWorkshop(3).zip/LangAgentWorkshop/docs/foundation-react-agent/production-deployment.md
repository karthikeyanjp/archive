# Production Deployment

This final section covers deploying your Foundation ReAct Agent to production environments with enterprise-grade reliability, security, and monitoring.

## 🎯 Learning Objectives

By the end of this section, you will:
- Deploy the agent to production environments
- Implement enterprise security and monitoring
- Configure scalable infrastructure
- Set up automated deployment pipelines
- Establish operational procedures
- Monitor and maintain production systems

## 🏗️ Production Architecture

```mermaid
graph TB
    A[Load Balancer] --> B[Agent Instance 1]
    A --> C[Agent Instance 2]
    A --> D[Agent Instance N]
    
    B --> E[Redis Cache]
    C --> E
    D --> E
    
    B --> F[PostgreSQL]
    C --> F
    D --> F
    
    G[Monitoring] --> B
    G --> C
    G --> D
    
    H[Log Aggregation] --> B
    H --> C
    H --> D
    
    I[API Gateway] --> A
    J[External APIs] --> B
    J --> C
    J --> D
```

## 📦 Step 1: Production Configuration

Create production-ready configuration:

```python
# src/react_agent/config/production.py
from .settings import Settings
from typing import Optional
import os

class ProductionSettings(Settings):
    """Production-specific settings with enhanced security."""
    
    # Enhanced security settings
    api_key_rotation_enabled: bool = True
    request_rate_limit: int = 100  # requests per minute
    max_concurrent_requests: int = 50
    
    # Database settings
    database_url: str = os.getenv("DATABASE_URL", "")
    database_pool_size: int = 10
    database_max_overflow: int = 20
    
    # Redis cache settings
    redis_url: str = os.getenv("REDIS_URL", "")
    cache_ttl_seconds: int = 3600
    
    # Monitoring settings
    enable_metrics: bool = True
    metrics_port: int = 9090
    health_check_interval: int = 30
    
    # Security settings
    cors_origins: list = ["https://your-domain.com"]
    enable_request_logging: bool = True
    log_sensitive_data: bool = False
    
    # Performance settings
    worker_count: int = int(os.getenv("WORKER_COUNT", "4"))
    worker_timeout: int = 300
    keepalive_timeout: int = 65
    
    class Config:
        env_file = ".env.production"
        env_file_encoding = "utf-8"

# Production settings instance
production_settings = ProductionSettings()
```

## 🐳 Step 2: Docker Configuration

Create Docker setup for containerized deployment:

```dockerfile
# Dockerfile
FROM python:3.11-slim as builder

# Set environment variables
ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1

# Install system dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Install Poetry
RUN pip install poetry

# Set work directory
WORKDIR /app

# Copy Poetry files
COPY pyproject.toml poetry.lock ./

# Configure Poetry
RUN poetry config virtualenvs.create false

# Install dependencies
RUN poetry install --only=main --no-interaction --no-ansi

# Production stage
FROM python:3.11-slim as production

# Set environment variables
ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PATH="/app/.venv/bin:$PATH"

# Create non-root user
RUN groupadd -r appuser && useradd -r -g appuser appuser

# Install runtime dependencies
RUN apt-get update && apt-get install -y \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Set work directory
WORKDIR /app

# Copy Python dependencies from builder stage
COPY --from=builder /usr/local/lib/python3.11/site-packages /usr/local/lib/python3.11/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin

# Copy application code
COPY src/ ./src/
COPY scripts/ ./scripts/

# Create directories for logs and data
RUN mkdir -p logs data && chown -R appuser:appuser /app

# Switch to non-root user
USER appuser

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD python scripts/health_check.py

# Expose port
EXPOSE 8000

# Run the application
CMD ["python", "-m", "uvicorn", "src.react_agent.api:app", "--host", "0.0.0.0", "--port", "8000"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  agent:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:password@postgres:5432/reactagent
      - REDIS_URL=redis://redis:6379
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - CHECKCOVERAGE_API_KEY=${CHECKCOVERAGE_API_KEY}
      - GETCOPY_API_KEY=${GETCOPY_API_KEY}
    depends_on:
      - postgres
      - redis
    volumes:
      - ./logs:/app/logs
    restart: unless-stopped
    
  postgres:
    image: postgres:15
    environment:
      - POSTGRES_DB=reactagent
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./sql/init.sql:/docker-entrypoint-initdb.d/init.sql
    restart: unless-stopped
    
  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
    restart: unless-stopped
    
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - agent
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
```

## 🔧 Step 3: API Service Implementation

Create a production API service:

```python
# src/react_agent/api.py
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import asyncio
import time
from datetime import datetime

from .agent import ReactAgentWithMonitoring
from .config.production import production_settings
from .utils.helpers import setup_logging

# Initialize logging
logger = setup_logging(
    level=production_settings.log_level,
    format_type=production_settings.log_format,
    log_file=production_settings.log_file
)

# Initialize FastAPI app
app = FastAPI(
    title="Foundation ReAct Agent API",
    description="Enterprise ReAct Agent with CheckCoverage and GetCopy tools",
    version="1.0.0",
    docs_url="/docs" if production_settings.debug else None,
    redoc_url="/redoc" if production_settings.debug else None
)

# Add middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=production_settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=production_settings.cors_origins + ["localhost", "127.0.0.1"]
)

# Global agent instance
agent = ReactAgentWithMonitoring()

# Request/Response models
class AgentRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    include_metadata: bool = False

class AgentResponse(BaseModel):
    response: str
    session_id: str
    response_time: float
    status: str
    metadata: Optional[Dict[str, Any]] = None

class HealthCheckResponse(BaseModel):
    status: str
    timestamp: str
    uptime_seconds: float
    version: str

# Application state
app_start_time = time.time()

@app.on_event("startup")
async def startup_event():
    """Initialize application on startup."""
    logger.info("Starting Foundation ReAct Agent API")
    logger.info(f"Agent loaded with {len(agent.tools)} tools")

@app.on_event("shutdown") 
async def shutdown_event():
    """Cleanup on application shutdown."""
    logger.info("Shutting down Foundation ReAct Agent API")

@app.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """Health check endpoint for load balancers."""
    try:
        # Quick agent test
        test_result = await agent.run_with_monitoring("Health check")
        status = "healthy" if test_result["status"] == "success" else "degraded"
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        status = "unhealthy"
    
    return HealthCheckResponse(
        status=status,
        timestamp=datetime.utcnow().isoformat(),
        uptime_seconds=time.time() - app_start_time,
        version="1.0.0"
    )

@app.post("/chat", response_model=AgentResponse)
async def chat_with_agent(
    request: AgentRequest,
    background_tasks: BackgroundTasks
):
    """Main chat endpoint for interacting with the agent."""
    try:
        logger.info(f"Processing request: {request.message[:100]}...")
        
        # Run the agent
        result = await agent.run_with_monitoring(request.message)
        
        # Prepare response
        response = AgentResponse(
            response=result["response"],
            session_id=result["session_id"],
            response_time=result["response_time"],
            status=result["status"]
        )
        
        # Add metadata if requested
        if request.include_metadata:
            response.metadata = {
                "tool_calls": result.get("tool_calls", 0),
                "conversation_length": len(agent.get_conversation_history()),
                "performance": agent.get_performance_report()["summary"]
            }
        
        # Background logging
        background_tasks.add_task(
            log_interaction, 
            request.message, 
            result["response"],
            result["response_time"]
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Chat request failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/metrics")
async def get_metrics():
    """Metrics endpoint for monitoring systems."""
    try:
        report = agent.get_performance_report()
        
        # Prometheus-style metrics
        metrics = f"""
# HELP agent_requests_total Total number of agent requests
# TYPE agent_requests_total counter
agent_requests_total {report['summary']['total_requests']}

# HELP agent_requests_successful_total Total number of successful requests
# TYPE agent_requests_successful_total counter  
agent_requests_successful_total {report['summary']['successful_requests']}

# HELP agent_response_time_seconds Average response time in seconds
# TYPE agent_response_time_seconds gauge
agent_response_time_seconds {report['summary']['average_response_time']}

# HELP agent_success_rate_percent Success rate percentage
# TYPE agent_success_rate_percent gauge
agent_success_rate_percent {report['summary']['success_rate']}
"""
        
        return metrics.strip()
        
    except Exception as e:
        logger.error(f"Metrics request failed: {e}")
        raise HTTPException(status_code=500, detail="Metrics unavailable")

async def log_interaction(user_message: str, agent_response: str, response_time: float):
    """Background task for logging interactions."""
    logger.info(
        "Interaction logged",
        extra={
            "user_message_length": len(user_message),
            "agent_response_length": len(agent_response),
            "response_time": response_time,
            "timestamp": datetime.utcnow().isoformat()
        }
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api:app",
        host="0.0.0.0",
        port=8000,
        workers=production_settings.worker_count,
        access_log=production_settings.enable_request_logging
    )
```

## 🚀 Step 4: Kubernetes Deployment

Create Kubernetes manifests for scalable deployment:

```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: react-agent

---
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: agent-config
  namespace: react-agent
data:
  LOG_LEVEL: "INFO"
  LOG_FORMAT: "json"
  WORKER_COUNT: "4"
  MAX_CONCURRENT_REQUESTS: "50"

---
# k8s/secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: agent-secrets
  namespace: react-agent
type: Opaque
stringData:
  OPENAI_API_KEY: "your-openai-key"
  CHECKCOVERAGE_API_KEY: "your-coverage-key"
  GETCOPY_API_KEY: "your-copy-key"
  DATABASE_URL: "postgresql://user:password@postgres:5432/reactagent"
  REDIS_URL: "redis://redis:6379"

---
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: react-agent
  namespace: react-agent
spec:
  replicas: 3
  selector:
    matchLabels:
      app: react-agent
  template:
    metadata:
      labels:
        app: react-agent
    spec:
      containers:
      - name: react-agent
        image: your-registry/react-agent:latest
        ports:
        - containerPort: 8000
        envFrom:
        - configMapRef:
            name: agent-config
        - secretRef:
            name: agent-secrets
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"

---
# k8s/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: react-agent-service
  namespace: react-agent
spec:
  selector:
    app: react-agent
  ports:
  - port: 80
    targetPort: 8000
  type: ClusterIP

---
# k8s/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: react-agent-ingress
  namespace: react-agent
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  tls:
  - hosts:
    - api.your-domain.com
    secretName: react-agent-tls
  rules:
  - host: api.your-domain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: react-agent-service
            port:
              number: 80
```

## 📊 Step 5: Monitoring and Observability

Set up comprehensive monitoring:

```yaml
# monitoring/prometheus.yml
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
  namespace: react-agent
data:
  prometheus.yml: |
    global:
      scrape_interval: 15s
    
    scrape_configs:
    - job_name: 'react-agent'
      static_configs:
      - targets: ['react-agent-service:80']
      metrics_path: '/metrics'
      scrape_interval: 10s
    
    - job_name: 'kubernetes-pods'
      kubernetes_sd_configs:
      - role: pod
        namespaces:
          names:
          - react-agent

---
# monitoring/grafana-dashboard.json
{
  "dashboard": {
    "title": "ReAct Agent Metrics",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(agent_requests_total[5m])",
            "legendFormat": "Requests/sec"
          }
        ]
      },
      {
        "title": "Success Rate", 
        "type": "singlestat",
        "targets": [
          {
            "expr": "agent_success_rate_percent",
            "legendFormat": "Success %"
          }
        ]
      },
      {
        "title": "Response Time",
        "type": "graph", 
        "targets": [
          {
            "expr": "agent_response_time_seconds",
            "legendFormat": "Response Time (s)"
          }
        ]
      }
    ]
  }
}
```

## 🔄 Step 6: CI/CD Pipeline

Create automated deployment pipeline:

```yaml
# .gitlab-ci.yml (GitLab CI/CD)
stages:
  - test
  - build
  - deploy

variables:
  DOCKER_IMAGE: $CI_REGISTRY_IMAGE:$CI_COMMIT_SHA
  KUBECONFIG: /tmp/kubeconfig

test:
  stage: test
  image: python:3.11
  before_script:
    - pip install poetry
    - poetry install
  script:
    - poetry run pytest tests/ -v --cov=src
  coverage: '/TOTAL.*\s+(\d+%)$/'

build:
  stage: build
  image: docker:20.10.16
  services:
    - docker:20.10.16-dind
  before_script:
    - docker login -u $CI_REGISTRY_USER -p $CI_REGISTRY_PASSWORD $CI_REGISTRY
  script:
    - docker build -t $DOCKER_IMAGE .
    - docker push $DOCKER_IMAGE
  only:
    - main

deploy:
  stage: deploy
  image: bitnami/kubectl:latest
  before_script:
    - echo $KUBE_CONFIG | base64 -d > $KUBECONFIG
    - chmod 600 $KUBECONFIG
  script:
    - kubectl set image deployment/react-agent react-agent=$DOCKER_IMAGE -n react-agent
    - kubectl rollout status deployment/react-agent -n react-agent
  environment:
    name: production
    url: https://api.your-domain.com
  only:
    - main
  when: manual
```

## 📋 Step 7: Operational Procedures

Create operational runbooks:

```markdown
# Production Runbook

## Deployment Procedures

### Normal Deployment
1. Merge changes to main branch
2. Verify CI/CD pipeline passes
3. Trigger manual deployment in GitLab
4. Monitor deployment progress
5. Verify health checks pass
6. Test critical user journeys

### Rollback Procedures
```bash
# Quick rollback to previous version
kubectl rollout undo deployment/react-agent -n react-agent

# Rollback to specific revision
kubectl rollout history deployment/react-agent -n react-agent
kubectl rollout undo deployment/react-agent --to-revision=<revision> -n react-agent
```

### Scaling Operations
```bash
# Scale up for high traffic
kubectl scale deployment react-agent --replicas=6 -n react-agent

# Scale down during low usage
kubectl scale deployment react-agent --replicas=2 -n react-agent
```

## Monitoring and Alerting

### Key Metrics to Monitor
- Request rate and response times
- Success rate and error rates  
- Resource utilization (CPU, memory)
- External API health and latency

### Alert Thresholds
- Success rate < 95%
- Average response time > 5 seconds
- Error rate > 5%
- CPU usage > 80%
- Memory usage > 90%

## Troubleshooting

### Common Issues
1. **High Response Times**
   - Check external API latency
   - Review database connection pool
   - Monitor resource utilization

2. **API Failures**
   - Verify API keys are valid
   - Check rate limiting status
   - Review network connectivity

3. **Memory Leaks**
   - Monitor long-running processes
   - Check conversation state cleanup
   - Review object lifecycle management

### Log Analysis
```bash
# View application logs
kubectl logs -f deployment/react-agent -n react-agent

# Search for errors
kubectl logs deployment/react-agent -n react-agent | grep ERROR

# View specific pod logs
kubectl logs <pod-name> -n react-agent
```
```

## ✅ Production Deployment Complete

Your Foundation ReAct Agent is now production-ready with:

- ✅ Enterprise-grade configuration management
- ✅ Docker containerization for consistent deployment
- ✅ Kubernetes manifests for scalable infrastructure
- ✅ FastAPI service with proper error handling
- ✅ Comprehensive monitoring and observability
- ✅ Automated CI/CD deployment pipeline
- ✅ Operational procedures and runbooks

The agent is ready for enterprise deployment with proper security, monitoring, and operational procedures in place.